# -*- coding: utf-8 -*-
"""YTD 影片下載器 - 本機服務 (只使用 Python 標準函式庫)

架構: 本程式在 127.0.0.1 開一個小型網頁服務, 介面用瀏覽器 (Edge 應用程式視窗) 顯示,
實際下載交給 bin\\yt-dlp.exe, 合併/轉檔交給 bin\\ffmpeg.exe。
"""
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import argparse
import base64
import hashlib
import collections
import html as htmllib
import io
import json
import math
import datetime
import mimetypes
import re
import secrets
import shutil
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(HERE)
WEB = os.path.join(HERE, "web")
BIN = os.path.join(ROOT, "bin")
DATA = os.path.join(ROOT, "data")
TMP = os.path.join(DATA, "tmp")
BACKUP = os.path.join(ROOT, "backup")

IS_WIN = os.name == "nt"
NOWIN = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW
PORTS = range(47821, 47831)
TOKEN = secrets.token_urlsafe(24)
VER_RE = re.compile(r"^V(\d+)\.(\d+)\.(\d+)$")
PKG_RE = re.compile(r"^YTD_(V\d+\.\d+\.\d+)")

STATE = {
    "port": 0,
    "last_ping": time.time() + 120,  # 啟動寬限
    "bye_at": 0.0,
    "ytdlp_version": "",
    "httpd": None,
}
JOBS = {}
JOBS_LOCK = threading.Lock()
SEM = threading.Semaphore(3)
JOB_SEQ = [0]


# ----------------------------------------------------------------- 基礎工具
def log(msg):
    try:
        with open(os.path.join(DATA, "ytd.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + str(msg) + "\n")
    except Exception:
        pass


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return default


def write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def current_version():
    return read_json(os.path.join(HERE, "version.json"), {}).get("version", "V0.0.00")


def vtuple(s):
    m = VER_RE.match(s or "")
    return tuple(int(x) for x in m.groups()) if m else None


def default_download_dir():
    return os.path.join(os.path.expanduser("~"), "Downloads")


def load_config():
    cfg = {"download_dir": default_download_dir(), "container": "mp4", "mp3_bitrate": 320, "login_mode": "none", "core_channel": "stable", "update_token": "", "sponsorblock": False, "use_idm": False, "skip_downloaded": True,
                  "gain": 0, "noclip": True, "lyrics": True}
    cfg.update(read_json(os.path.join(DATA, "config.json"), {}))
    return cfg


def save_config(cfg):
    write_json(os.path.join(DATA, "config.json"), cfg)


def child_env():
    env = dict(os.environ)
    env["PATH"] = BIN + os.pathsep + env.get("PATH", "")
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    return env


def tool(name):
    """尋找 bin 內的工具, 找不到再找 PATH。"""
    override = os.environ.get("YTD_" + name.upper().replace("-", ""))
    if override:
        return override
    for cand in (os.path.join(BIN, name + ".exe"), os.path.join(BIN, name)):
        if os.path.isfile(cand):
            return cand
    return shutil.which(name, path=child_env()["PATH"])


def run(cmd, timeout=120):
    p = subprocess.run(
        cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=timeout, creationflags=NOWIN, env=child_env(),
    )
    return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace")


def powershell(script, env_extra=None, timeout=600):
    """執行一段 PowerShell (用 EncodedCommand 避免引號問題), 回傳 stdout。"""
    enc = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    env = child_env()
    env.update(env_extra or {})
    p = subprocess.run(
        ["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=timeout, creationflags=NOWIN, env=env,
    )
    return p.stdout.decode("ascii", "replace").strip()


class AppError(Exception):
    pass


def last_error(text):
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    errs = [l for l in lines if l.startswith("ERROR")]
    msg = errs[-1] if errs else (lines[-1] if lines else "未知錯誤")
    return re.sub(r"^ERROR:\s*", "", msg)


# ----------------------------------------------------------------- 解析影片
YT_ID_RE = re.compile(
    r"(?:youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|embed/|live/)|youtu\.be/)([A-Za-z0-9_-]{11})"
)
RES_TAG = {4320: "8K", 2160: "4K", 1440: "2K", 1080: "Full HD", 720: "HD"}


YT_HOST_RE = re.compile(r"^https?://([\w-]+\.)*(youtube\.com|youtu\.be|youtube-nocookie\.com)(/|$)", re.I)
MEDIA_HOST_RE = re.compile(
    r"^https?://([\w-]+\.)*(youtube\.com|youtu\.be|instagram\.com|facebook\.com|fb\.watch|fb\.com|"
    r"threads\.net|threads\.com|tiktok\.com|twitter\.com|x\.com|twitch\.tv|vimeo\.com|bilibili\.com)(/|$)", re.I)
COOKIE_FILE = os.path.join(DATA, "cookies.txt")
BROWSERS = ("firefox", "edge", "chrome")


def is_youtube(url):
    return bool(YT_HOST_RE.match(url or "")) or (url or "").startswith("ytsearch")


def cookie_args(url):
    """IG / FB 等網站的登入資訊; YouTube 只在「登入 YouTube」之後才帶入 (Premium 會員的高音質)。"""
    if is_youtube(url):
        return ["--cookies", COOKIE_FILE] if yt_logged_in() else []
    mode = load_config().get("login_mode")
    if mode in BROWSERS:
        return ["--cookies-from-browser", mode]
    if mode == "file" and os.path.isfile(COOKIE_FILE):
        return ["--cookies", COOKIE_FILE]
    # 登入方式沒選 cookies.txt, 但 YTD 的登入視窗已存了這個網站的登入資料: 一樣帶入
    host = (urllib.request.urlparse(url).hostname or "").lower()
    st = cookie_summary()
    if host == "twitter.com" or host.endswith(".twitter.com"):
        host = "x.com"
    for k, (_, d, _) in LOGIN_SITES.items():
        if (host == d or host.endswith("." + d)) and st.get(k) == "ok":
            return ["--cookies", COOKIE_FILE]
    return []


LOGIN_SITES = {"instagram": ("Instagram", "instagram.com", ("sessionid",)),
               "facebook": ("Facebook", "facebook.com", ("c_user", "xs")),
               "threads": ("Threads", "threads.com", ("sessionid",)),
               "x": ("X", "x.com", ("auth_token",)),
               "youtube": ("YouTube", "youtube.com", ("SAPISID",))}


def yt_logged_in():
    return os.path.isfile(COOKIE_FILE) and cookie_summary().get("youtube") == "ok"


YT_ID_RE = re.compile(r"(?:v=|youtu\.be/|/shorts/|/live/)([\w-]{11})")


def yt_music_url(url):
    """登入 YouTube 時, 音訊改從 YouTube Music 取得: Premium 會員可拿到 256kbps 的高音質音軌。"""
    m = YT_ID_RE.search(url or "")
    return "https://music.youtube.com/watch?v=" + m.group(1) if m else url


# Premium 高音質: 774 = Opus 256kbps, 141 = AAC 256kbps (只有 Premium 會員拿得到; 沒有就用一般最佳音質)
PREMIUM_MP3_FMT = "774/141/ba/b"
PREMIUM_M4A_FMT = "141/ba[ext=m4a]/ba/b"


def cookie_summary():
    """檢查匯入的 cookies.txt 是否含有各網站的登入資料 (只看名稱與期限, 不回傳內容)。
    ok=有登入資料, expired=已過期, nologin=有該網站的 cookies 但不是登入狀態, none=沒有該網站。"""
    out = {k: "none" for k in LOGIN_SITES}
    if not os.path.isfile(COOKIE_FILE):
        return out
    found = {k: {} for k in LOGIN_SITES}
    seen = set()
    try:
        with open(COOKIE_FILE, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith("#HttpOnly_"):
                    line = line[len("#HttpOnly_"):]
                elif line.startswith("#") or not line.strip():
                    continue
                p = line.rstrip("\r\n").split("\t")
                if len(p) < 7:
                    continue
                dom = p[0].lstrip(".").lower()
                for k, (_, d, names) in LOGIN_SITES.items():
                    if dom == d or dom.endswith("." + d):
                        seen.add(k)
                        if p[5] in names and p[6]:
                            exp = int(p[4]) if p[4].isdigit() else 0
                            found[k][p[5]] = "expired" if (exp and exp < time.time()) else "ok"
    except Exception as e:
        log("cookie_summary failed: %r" % e)
        return out
    for k, (_, _, names) in LOGIN_SITES.items():
        if all(n in found[k] for n in names):
            out[k] = "expired" if "expired" in found[k].values() else "ok"
        elif k in seen:
            out[k] = "nologin"
    return out


def site_key(url):
    host = (urllib.request.urlparse(url or "").hostname or "").lower()
    if host == "instagram.com" or host.endswith(".instagram.com"):
        return "instagram"
    if host.endswith(("facebook.com", "fb.watch", "fb.com")):
        return "facebook"
    if YT_HOST_RE.match(url or ""):
        return "youtube"
    return ""


def friendly_error(msg, url=""):
    msg = msg or "未知錯誤"
    if re.search(r"cookie database|decrypt|DPAPI|could not find .* cookies|keyring", msg, re.I):
        return msg + "　→ 無法讀取瀏覽器的登入資料。Chrome / Edge 常會擋下讀取, 請在「登入設定」改用 Firefox 或匯入 cookies.txt。"
    if re.search(r"log ?in|logged|cookies|rate.?limit|private|not available|empty media response|"
                 r"unable to extract|registered users|authentication", msg, re.I):
        mode = load_config().get("login_mode")
        if not url or not cookie_args(url):
            return msg + "　→ 【目前沒有使用登入資料】這個內容可能需要登入才能下載 (限時動態、私人帳號、不公開貼文), 請到右上角「登入設定」設定後再試。"
        key = site_key(url)
        if mode == "file" and key:
            name, state = LOGIN_SITES[key][0], cookie_summary()[key]
            if state != "ok":
                why = {"expired": "的登入資料已過期", "nologin": "的 cookies, 但不是登入狀態 (匯出時沒有登入)",
                       "none": "的 cookies (匯出時不是在 %s 的分頁)" % name}[state]
                return msg + "　→ 【cookies.txt 有問題】匯入的檔案裡%s%s。請在 Chrome 開啟 %s 並確認已登入, 在那個分頁重新匯出 cookies.txt 再匯入一次。" % (
                    "沒有 " + name if state == "none" else ("有 " + name if state == "nologin" else name), why, LOGIN_SITES[key][1])
        return msg + ("　→ 【已帶入登入資料, 但網站仍拒絕】可能原因: (1) 登入已失效, 請重新匯出 cookies.txt 再匯入; "
                      "(2) 這則限時動態已過期, 或你的帳號看不到它; (3) 下載核心暫時不支援, 請按右上角「更新下載核心」後再試。")
    return msg


def save_cookie_file(data):
    try:
        text = data.decode("utf-8-sig")
    except Exception:
        raise AppError("這不是文字格式的 cookies.txt")
    rows = [l for l in text.splitlines() if l.strip() and not l.startswith("#") or l.startswith("#HttpOnly_")]
    if not rows or not all(len(l.split("\t")) >= 7 for l in rows[:20]):
        raise AppError("檔案格式不正確, 需要 Netscape 格式的 cookies.txt (由瀏覽器擴充功能匯出)")
    if not text.lstrip().startswith("#"):
        text = "# Netscape HTTP Cookie File\n" + text
    with open(COOKIE_FILE, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    cfg = load_config()
    cfg["login_mode"] = "file"
    save_config(cfg)
    return len(rows), cookie_summary()


def entry_thumb(e):
    if e.get("thumbnail"):
        return e["thumbnail"]
    t = [x.get("url") for x in (e.get("thumbnails") or []) if isinstance(x, dict) and x.get("url")]
    return t[-1] if t else ""


def check_url(url):
    url = (url or "").strip()
    if not re.match(r"^https?://\S+$", url):
        raise AppError("請貼上完整的影片網址 (以 http:// 或 https:// 開頭)")
    return url


def fmt_size(fmt, duration):
    s = fmt.get("filesize") or fmt.get("filesize_approx")
    if not s and fmt.get("tbr") and duration:
        s = fmt["tbr"] * 125 * duration
    return int(s or 0)


def analyze(url):
    ref = spotify_ref(url)
    if ref:
        return analyze_spotify(*ref)
    mref = music_ref(url)
    if mref:
        return analyze_music_url(mref)
    url = check_url(url)
    if SHARE_RE.match(url):
        url = resolve_share(url)
    tm = THREADS_RE.match(url)
    if tm:
        return threads_post(url, tm.group(1) or "", tm.group(2))
    xm = X_RE.match(url)
    if xm:
        url = "https://x.com/%s/status/%s" % (xm.group(1) or "i", xm.group(2))
        try:
            return x_post(url, xm.group(2))
        except AppError as e:
            # 公開資料讀不到 (例如需要登入的敏感內容): 改用下載核心 (會帶入「登入 X」的資料)
            log("x_post fallback: %s" % e)
    ig_err = ""
    m = IG_STORY_RE.match(url)
    if m and m.group(1).lower() != "highlights":
        try:
            return ig_story(url, m.group(1), m.group(2))
        except AppError as e:
            ig_err = str(e)
        except Exception as e:
            log("ig_story error: %r" % e)
            ig_err = "內建的限時動態讀取發生錯誤: %s" % e
    pm = IG_POST_RE.match(url)
    post = None
    if pm:
        try:
            post = ig_post(url, pm.group(1), pm.group(2))
        except AppError as e:
            ig_err = str(e)
        except Exception as e:
            log("ig_post error: %r" % e)
            ig_err = "內建的貼文讀取發生錯誤: %s" % e
        # 含有照片的貼文由內建讀取處理 (下載核心不支援照片); 純影片貼文交給下載核心 (畫質較高)
        if post and any(d["kind"] == "photo" for d in post["direct"]):
            return post
    if not MEDIA_HOST_RE.match(url) and not re.search(r"\.(m3u8|mpd)(\?|$)", url, re.I):
        f = probe_file(url)
        if f:
            return f
    exe = tool("yt-dlp")
    if not exe:
        raise AppError("找不到 yt-dlp, 請重新執行安裝檔修復環境")
    try:
        rc, out, err = run(
            [exe, "-J", "--no-playlist", "--flat-playlist", "--no-warnings",
             "--encoding", "utf-8"] + cookie_args(url) + ["--", url], timeout=180)
    except subprocess.TimeoutExpired:
        raise AppError("解析逾時, 請檢查網路後再試一次")
    if rc != 0:
        if post:  # 下載核心失敗, 但內建讀取有拿到影片
            return post
        if ig_err:  # 內建讀取與下載核心都失敗: 顯示內建讀取的原因 (下載核心目前對限時動態本來就失效)
            raise AppError(ig_err)
        raise AppError(friendly_error(last_error(err), url))
    try:
        info = json.loads(out)
    except Exception:
        raise AppError("無法讀取影片資訊")
    if info.get("_type") == "playlist":
        entries = [e for e in (info.get("entries") or []) if isinstance(e, dict)]
        if not entries:
            if post:
                return post
            raise AppError(ig_err or "這個網址沒有找到可下載的影片或圖片")
        if len(entries) == 1 and entries[0].get("formats"):
            entries[0].setdefault("webpage_url", url)
            info = entries[0]
        else:
            first = entries[0]
            return {
                "source": "multi", "url": url, "id": info.get("id") or "", "youtube_id": "",
                "title": info.get("title") or first.get("title") or "(多個項目)",
                "uploader": info.get("uploader") or info.get("channel") or first.get("uploader") or "",
                "duration": 0, "view_count": None, "upload_date": "", "is_live": False,
                "thumbnail": entry_thumb(info) or entry_thumb(first),
                "site": info.get("extractor_key") or first.get("ie_key") or "",
                "qualities": [], "audio_size": 0, "count": len(entries),
                "items": [{"title": e.get("title") or e.get("id") or "", "duration": int(e.get("duration") or 0),
                           "channel": e.get("uploader") or e.get("channel") or ""} for e in entries[:100]],
            }

    duration = info.get("duration") or 0
    formats = info.get("formats") or []
    audio = [f for f in formats if f.get("acodec") not in (None, "none") and f.get("vcodec") in (None, "none")]
    best_audio = max((fmt_size(f, duration) for f in audio), default=0)

    groups = {}
    for f in formats:
        if f.get("vcodec") in (None, "none"):
            continue
        w, h = f.get("width") or 0, f.get("height") or 0
        res = min(w, h) if (w and h) else h
        if not res:
            continue
        g = groups.setdefault(res, {"res": res, "fps": 0, "size": 0, "tbr": -1, "hdr": False})
        g["fps"] = max(g["fps"], int(f.get("fps") or 0))
        if (f.get("dynamic_range") or "SDR") != "SDR":
            g["hdr"] = True
        tbr = f.get("tbr") or 0
        if tbr > g["tbr"]:
            g["tbr"] = tbr
            size = fmt_size(f, duration)
            if size and f.get("acodec") in (None, "none"):
                size += best_audio
            g["size"] = size
    qualities = []
    for res in sorted(groups, reverse=True):
        g = groups[res]
        qualities.append({
            "res": res, "label": "%dp" % res, "tag": RES_TAG.get(res, ""),
            "fps": g["fps"], "hdr": g["hdr"], "size": g["size"],
        })

    m = YT_ID_RE.search(info.get("webpage_url") or url) or YT_ID_RE.search(url)
    extras = yt_extras(m.group(1)) if m else {}
    if extras and extras.get("likes") is None:
        extras["likes"] = info.get("like_count")
    return dict(extras, **{
        "url": info.get("webpage_url") or url,
        "id": info.get("id"),
        "youtube_id": m.group(1) if m else "",
        "title": info.get("title") or "(無標題)",
        "uploader": info.get("uploader") or info.get("channel") or "",
        "duration": duration,
        "view_count": info.get("view_count"),
        "upload_date": info.get("upload_date") or "",
        "thumbnail": info.get("thumbnail") or "",
        "is_live": bool(info.get("is_live")),
        "site": info.get("extractor_key") or "",
        "qualities": qualities,
        "audio_size": best_audio,
    })


# ----------------------------------------------------------------- YouTube 社群資料
# 與 ReVanced 相同的兩個公開服務: Return YouTube Dislike (倒讚數)、SponsorBlock (社群標記的業配片段)。
# 任一個查不到都不影響解析與下載。
SB_CATS = ("sponsor", "selfpromo", "interaction")


def yt_extras(vid):
    out = {"likes": None, "dislikes": None, "sb": []}

    def ryd():
        _, body = http_get("https://returnyoutubedislikeapi.com/votes?videoId=" + vid, timeout=6, limit=1 << 16)
        d = json.loads(body.decode("utf-8"))
        out["likes"], out["dislikes"] = d.get("likes"), d.get("dislikes")

    def sb():
        q = urllib.request.quote(json.dumps(list(SB_CATS), separators=(",", ":")))
        try:
            _, body = http_get("https://sponsor.ajay.app/api/skipSegments?videoID=%s&categories=%s" % (vid, q),
                               timeout=6, limit=1 << 18)
        except urllib.error.HTTPError as e:
            if e.code == 404:  # 沒有任何標記
                return
            raise
        segs = []
        for x in json.loads(body.decode("utf-8")):
            seg = x.get("segment") or []
            if x.get("category") in SB_CATS and len(seg) == 2:
                segs.append({"cat": x["category"], "start": float(seg[0]), "end": float(seg[1])})
        out["sb"] = sorted(segs, key=lambda g: g["start"])[:30]

    def safe(fn):
        try:
            fn()
        except Exception as e:
            log("yt_extras %s failed: %r" % (fn.__name__, e))

    ts = [threading.Thread(target=safe, args=(f,), daemon=True) for f in (ryd, sb)]
    for t in ts:
        t.start()
    for t in ts:
        t.join(8)
    return out


# ----------------------------------------------------------------- Spotify 連結
# Spotify 的音訊有 DRM, 這裡只讀取公開的歌曲資訊 (歌名/歌手/長度/封面),
# 再到 YouTube 搜尋對應的音訊。
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36")
SP_KINDS = "track|album|playlist|episode|show|artist"
SP_RE = re.compile(r"open\.spotify\.com/(?:intl-[A-Za-z-]+/)?(?:embed/)?(%s)/([A-Za-z0-9]{22})" % SP_KINDS)
SP_URI_RE = re.compile(r"^spotify:(%s):([A-Za-z0-9]{22})$" % SP_KINDS)
SP_SHORT_RE = re.compile(r"^https?://(spotify\.link|spotify\.app\.link)/\S+$")
BAD_WORDS = ("live", "cover", "remix", "karaoke", "instrumental", "reaction", "sped up", "slowed",
             "nightcore", "8d", "伴奏", "翻唱", "現場", "演唱會", "純音樂", "卡拉")


def http_get(url, timeout=20, limit=6 << 20):
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Accept-Language": "zh-TW,zh;q=0.9,en;q=0.8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.geturl(), r.read(limit)


def spotify_ref(url):
    u = (url or "").strip()
    m = SP_URI_RE.match(u) or SP_RE.search(u)
    if m:
        return m.group(1), m.group(2)
    if SP_SHORT_RE.match(u):
        try:
            final, body = http_get(u)
            m = SP_RE.search(final) or SP_RE.search(body.decode("utf-8", "replace"))
        except Exception:
            m = None
        if not m:
            raise AppError("無法解析這個 Spotify 短網址, 請改貼 open.spotify.com/track/... 的完整連結")
        return m.group(1), m.group(2)
    return None


def _find_track(obj, depth=0):
    """在 Spotify 內嵌頁的 JSON 裡找出歌曲物件。"""
    if depth > 12:
        return None
    if isinstance(obj, dict):
        if isinstance(obj.get("artists"), list) and (obj.get("name") or obj.get("title")) \
                and "duration" in obj:
            return obj
        for v in obj.values():
            r = _find_track(v, depth + 1)
            if r:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = _find_track(v, depth + 1)
            if r:
                return r
    return None


def _meta_tag(page, key):
    for pat in (r'<meta[^>]+(?:property|name)="%s"[^>]+content="([^"]*)"',
                r'<meta[^>]+content="([^"]*)"[^>]+(?:property|name)="%s"'):
        m = re.search(pat % re.escape(key), page)
        if m:
            return htmllib.unescape(m.group(1)).strip()
    return ""


def spotify_meta(sid):
    meta = {"name": "", "artists": [], "duration": 0, "cover": "", "year": "", "album": ""}
    # 1) 內嵌播放器頁: 資料最完整
    try:
        _, body = http_get("https://open.spotify.com/embed/track/" + sid)
        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', body.decode("utf-8", "replace"), re.S)
        t = _find_track(json.loads(m.group(1))) if m else None
        if t:
            meta["name"] = str(t.get("name") or t.get("title") or "")
            meta["artists"] = [str(a.get("name")) for a in t["artists"] if isinstance(a, dict) and a.get("name")]
            d = t.get("duration") or 0
            meta["duration"] = round(d / 1000) if d > 10000 else int(d)
            imgs = (t.get("visualIdentity") or {}).get("image") or (t.get("coverArt") or {}).get("sources") or []
            imgs = [i for i in imgs if isinstance(i, dict) and i.get("url")]
            if imgs:
                meta["cover"] = max(imgs, key=lambda i: i.get("maxHeight") or i.get("height") or 0)["url"]
            rd = t.get("releaseDate")
            if isinstance(rd, dict) and rd.get("isoString"):
                meta["year"] = str(rd["isoString"])[:4]
    except Exception as e:
        log("spotify embed failed: %r" % e)
    # 2) 歌曲網頁的 meta 標籤: 補齊缺少的欄位
    if not (meta["name"] and meta["artists"] and meta["cover"]):
        try:
            _, body = http_get("https://open.spotify.com/track/" + sid)
            page = body.decode("utf-8", "replace")
            meta["name"] = meta["name"] or _meta_tag(page, "og:title")
            if not meta["artists"]:
                a = _meta_tag(page, "music:musician_description")
                if not a:
                    parts = [x.strip() for x in _meta_tag(page, "og:description").split("·")]
                    a = parts[0] if len(parts) >= 2 else ""
                    a = re.sub(r"^.*?Spotify\.\s*", "", a)
                meta["artists"] = [x.strip() for x in a.split(",") if x.strip()]
            meta["cover"] = meta["cover"] or _meta_tag(page, "og:image")
            if not meta["duration"]:
                meta["duration"] = int(num(_meta_tag(page, "music:duration")) or 0)
            if not meta["year"]:
                meta["year"] = _meta_tag(page, "music:release_date")[:4]
        except Exception as e:
            log("spotify page failed: %r" % e)
    # 3) oEmbed: 最後手段, 只有歌名與封面
    if not meta["name"]:
        try:
            _, body = http_get("https://open.spotify.com/oembed?url=" +
                               urllib.request.quote("https://open.spotify.com/track/" + sid, safe=""))
            o = json.loads(body.decode("utf-8", "replace"))
            meta["name"] = str(o.get("title") or "")
            meta["cover"] = meta["cover"] or str(o.get("thumbnail_url") or "")
        except Exception as e:
            log("spotify oembed failed: %r" % e)
    return meta


def match_score(cand, name, artists, duration, index):
    t, ch, s = cand["title"].lower(), cand["channel"].lower(), 0
    if duration and cand["duration"]:
        d = abs(cand["duration"] - duration)
        s += 40 if d <= 2 else 30 if d <= 5 else 12 if d <= 15 else -25 if d > 45 else 0
    if ch.endswith("- topic"):
        s += 25
    if any(a.lower() in ch or a.lower() in t for a in artists):
        s += 15
    if name.lower() in t:
        s += 15
    for w in BAD_WORDS:
        if w in t and w not in name.lower():
            s -= 25
    return s - index * 2


def spotify_list(kind, sid):
    """Spotify 專輯 / 播放清單: 從內嵌播放器頁讀出曲目清單 (歌名、歌手、長度)。"""
    try:
        _, body = http_get("https://open.spotify.com/embed/%s/%s" % (kind, sid))
        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', body.decode("utf-8", "replace"), re.S)
        data = json.loads(m.group(1)) if m else None
    except Exception as e:
        log("spotify list failed: %r" % e)
        data = None
    ent, stack = None, [data]
    while stack and ent is None:
        o = stack.pop()
        if isinstance(o, dict):
            if isinstance(o.get("trackList"), list):
                ent = o
                break
            stack.extend(o.values())
        elif isinstance(o, list):
            stack.extend(o)
    if not ent or not ent["trackList"]:
        raise AppError("無法讀取這個 Spotify %s的曲目 (可能是私人清單或網路問題)" % ("專輯" if kind == "album" else "播放清單"))
    tracks = []
    for i, t in enumerate(ent["trackList"], 1):
        if not isinstance(t, dict) or not t.get("title"):
            continue
        d = t.get("duration") or 0
        tracks.append({"n": i, "id": str(t.get("uri") or "").split(":")[-1], "title": str(t["title"]),
                       "artist": str(t.get("subtitle") or ""), "duration": round(d / 1000) if d > 10000 else int(d)})
    srcs = [x for x in ((ent.get("coverArt") or {}).get("sources") or []) if isinstance(x, dict) and x.get("url")]
    cover = max(srcs, key=lambda x: x.get("height") or x.get("maxHeight") or 0)["url"] if srcs else ""
    rd = ent.get("releaseDate")
    year = str(rd.get("isoString") or "")[:4] if isinstance(rd, dict) else ""
    return {
        "source": "splist", "sp_kind": kind, "url": "https://open.spotify.com/%s/%s" % (kind, sid), "id": sid,
        "youtube_id": "", "title": str(ent.get("name") or ent.get("title") or "Spotify"),
        "uploader": str(ent.get("subtitle") or ""), "duration": sum(t["duration"] for t in tracks),
        "view_count": None, "upload_date": "", "year": year, "thumbnail": cover, "is_live": False,
        "site": "Spotify", "qualities": [], "audio_size": 0, "count": len(tracks), "tracks": tracks,
    }


def analyze_spotify(kind, sid):
    if kind in ("album", "playlist"):
        return spotify_list(kind, sid)
    if kind != "track":
        raise AppError("目前支援 Spotify 的單曲、專輯與播放清單連結, Podcast 與歌手頁尚未支援")
    meta = spotify_meta(sid)
    if not meta["name"]:
        raise AppError("無法讀取這首 Spotify 歌曲的資訊 (可能是網路問題或 Spotify 網頁改版), 可改貼 YouTube 網址下載")
    return match_track(meta, "https://open.spotify.com/track/" + sid, "Spotify", sid)


def match_track(meta, url, site, sid=""):
    """串流平台的單曲: 到 YouTube 找同一首歌 (串流音訊有版權保護, 無法直接下載)。
    meta: name, artists(list), duration(秒), year, cover, album"""
    exe = tool("yt-dlp")
    if not exe:
        raise AppError("找不到 yt-dlp, 請重新執行安裝檔修復環境")
    query = " ".join(meta["artists"][:2] + [meta["name"]])
    try:
        rc, out, err = run([exe, "-J", "--flat-playlist", "--no-warnings", "--encoding", "utf-8",
                            "--", "ytsearch8:" + query], timeout=120)
    except subprocess.TimeoutExpired:
        raise AppError("搜尋 YouTube 逾時, 請檢查網路後再試一次")
    if rc != 0:
        raise AppError(last_error(err))
    try:
        entries = json.loads(out).get("entries") or []
    except Exception:
        entries = []
    cands = []
    for i, e in enumerate(entries):
        if not e or not e.get("id"):
            continue
        c = {"id": e["id"], "url": "https://www.youtube.com/watch?v=" + e["id"],
             "title": e.get("title") or "", "channel": e.get("channel") or e.get("uploader") or "",
             "duration": int(e.get("duration") or 0)}
        c["score"] = match_score(c, meta["name"], meta["artists"], meta["duration"], i)
        cands.append(c)
    if not cands:
        raise AppError("在 YouTube 找不到「%s」的對應音訊" % query)
    cands.sort(key=lambda c: c["score"], reverse=True)
    artist = ", ".join(meta["artists"])
    return {
        "source": "spotify", "url": url, "id": sid,
        "youtube_id": cands[0]["id"], "title": meta["name"], "uploader": artist,
        "duration": meta["duration"] or cands[0]["duration"], "view_count": None,
        "upload_date": "", "year": meta["year"], "thumbnail": meta["cover"], "is_live": False,
        "site": site, "qualities": [], "audio_size": 0,
        "filename": (artist + " - " if artist else "") + meta["name"],
        "tags": {"title": meta["name"], "artist": artist, "date": meta["year"], "album": meta.get("album") or ""},
        "candidates": cands,
    }


# ----------------------------------------------------------------- 其他串流音樂平台
# Apple Music / Deezer / Tidal / LINE MUSIC / Amazon Music: 和 Spotify 一樣有版權保護, 無法直接下載。
# 讀取公開的歌曲資訊 (歌名、歌手、專輯、封面、長度), 再到 YouTube 找同一首歌。
MUSIC_RES = [
    ("apple", re.compile(r"music\.apple\.com/(?:([a-z]{2})/)?(song|album|playlist)/(?:[^/?#]+/)?([^/?#]+)(?:\?[^#]*?\bi=(\d+))?", re.I)),
    ("deezer", re.compile(r"(?:www\.)?deezer\.com/(?:[a-z]{2}(?:-[a-z]{2})?/)?(track|album|playlist)/(\d+)", re.I)),
    ("tidal", re.compile(r"(?:listen\.)?tidal\.com/(?:browse/)?(?:album/\d+/)?(track|album|playlist)/([\w-]+)", re.I)),
    ("line", re.compile(r"music\.line\.me/(?:webapp/)?(track|album|playlist)/([\w-]+)", re.I)),
    ("amazon", re.compile(r"music\.amazon\.[a-z.]+/(tracks|albums|playlists|user-playlists)/(\w+)(?:\?[^#]*?\btrackAsin=(\w+))?", re.I)),
]
MUSIC_SHORT_RE = re.compile(r"^https?://(?:link\.deezer\.com|deezer\.page\.link|tidal\.link|amzn\.to)/\S+$", re.I)
SITE_NAMES = {"apple": "Apple Music", "deezer": "Deezer", "tidal": "TIDAL", "line": "LINE MUSIC", "amazon": "Amazon Music"}


def music_ref(url):
    u = (url or "").strip()
    if MUSIC_SHORT_RE.match(u):
        try:
            u = http_get(u, timeout=15, limit=1 << 20)[0]
        except Exception:
            return None
    for svc, rx in MUSIC_RES:
        m = rx.search(u)
        if m:
            return svc, m.groups(), u
    return None


def _json(url, limit=8 << 20):
    return json.loads(http_get(url, timeout=20, limit=limit)[1].decode("utf-8", "replace"))


def _iso_dur(v):
    m = re.match(r"P(?:T)?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?", str(v or ""))
    return int((int(m.group(1) or 0) * 3600 + int(m.group(2) or 0) * 60 + float(m.group(3) or 0))) if m else 0


def _ld_json(page):
    out = []
    for m in re.finditer(r'<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>', page, re.S):
        try:
            v = json.loads(m.group(1))
            out += v if isinstance(v, list) else [v]
        except Exception:
            pass
    return out


def _art(u, size=1000):
    return re.sub(r"/\d+x\d+(bb|cc)?\.(jpg|png|webp)$", "/%dx%dbb.jpg" % (size, size), u or "")


def _apple_track(x):
    return {"title": x.get("trackName") or "", "artist": x.get("artistName") or "",
            "album": x.get("collectionName") or "", "duration": round((x.get("trackTimeMillis") or 0) / 1000),
            "cover": _art(x.get("artworkUrl100")), "year": str(x.get("releaseDate") or "")[:4],
            "n": x.get("trackNumber") or 0}


def itunes_album(artist, album, cc="tw"):
    """用歌手+專輯名稱在 Apple 的公開資料庫找同一張專輯的曲目 (給沒有公開曲目清單的平台使用)。"""
    q = urllib.request.quote(("%s %s" % (artist, album)).strip())
    res = _json("https://itunes.apple.com/search?term=%s&entity=album&limit=10&country=%s" % (q, cc)).get("results") or []
    norm = lambda t: re.sub(r"[\W_]+", "", (t or "").lower())
    best = next((r for r in res if norm(r.get("collectionName")) == norm(album)), None) \
        or next((r for r in res if norm(album) and norm(album) in norm(r.get("collectionName"))), None)
    if not best:
        return None
    items = _json("https://itunes.apple.com/lookup?id=%s&entity=song&country=%s" % (best["collectionId"], cc)).get("results") or []
    return [_apple_track(x) for x in items if x.get("wrapperType") == "track"]


def _list_result(svc, kind, url, title, uploader, cover, year, tracks):
    tracks = [t for t in tracks if t.get("title")]
    if not tracks:
        raise AppError("讀不到這個%s的曲目" % {"album": "專輯", "playlist": "播放清單"}.get(kind, "連結"))
    for i, t in enumerate(tracks, 1):
        t["n"] = t.get("n") or i
        t.setdefault("id", "")
        for k in ("artist", "album", "cover", "year"):
            t[k] = t.get(k) or ""
        t["duration"] = int(t.get("duration") or 0)
    if kind == "album":
        tracks.sort(key=lambda t: (t.get("disc") or 1, t["n"]))
    return {
        "source": "splist", "sp_kind": kind, "url": url, "id": "", "youtube_id": "", "title": title or SITE_NAMES[svc],
        "uploader": uploader or "", "duration": sum(t["duration"] for t in tracks), "view_count": None, "upload_date": "",
        "year": year or "", "thumbnail": cover or tracks[0].get("cover") or "", "is_live": False, "site": SITE_NAMES[svc],
        "qualities": [], "audio_size": 0, "count": len(tracks), "tracks": tracks,
    }


def analyze_music(svc, g, url):
    site = SITE_NAMES[svc]
    try:
        if svc == "apple":
            cc, kind, aid, tid = (g[0] or "tw").lower(), g[1].lower(), g[2], g[3]
            if kind == "song" or tid:
                r = (_json("https://itunes.apple.com/lookup?id=%s&country=%s" % (tid or aid, cc)).get("results") or [None])[0]
                if not r:
                    raise AppError("讀不到這首 Apple Music 歌曲的資訊")
                t = _apple_track(r)
                return ("track", t)
            if kind == "album":
                items = _json("https://itunes.apple.com/lookup?id=%s&entity=song&country=%s" % (aid, cc)).get("results") or []
                col = next((x for x in items if x.get("wrapperType") == "collection"), {})
                tr = [_apple_track(x) for x in items if x.get("wrapperType") == "track"]
                for x, t in zip([x for x in items if x.get("wrapperType") == "track"], tr):
                    t["disc"] = x.get("discNumber") or 1
                return ("list", _list_result(svc, "album", url, col.get("collectionName"), col.get("artistName"),
                                             _art(col.get("artworkUrl100")), str(col.get("releaseDate") or "")[:4], tr))
            page = http_get(url, timeout=25)[1].decode("utf-8", "replace")  # 播放清單: 頁面附的結構化資料
            pl = next((x for x in _ld_json(page) if x.get("@type") == "MusicPlaylist"), None)
            if not pl:
                raise AppError("讀不到這個 Apple Music 播放清單 (可能是私人清單)")
            ids, names = [], {}
            for t in pl.get("track") or []:
                m = re.search(r"/(\d+)(?:\?|$)", str(t.get("url") or ""))
                if m:
                    ids.append(m.group(1))
                    names[m.group(1)] = {"title": t.get("name") or "", "duration": _iso_dur(t.get("duration"))}
            found = {}
            for i in range(0, len(ids), 150):
                for x in _json("https://itunes.apple.com/lookup?id=%s&country=%s" % (",".join(ids[i:i + 150]), cc)).get("results") or []:
                    if x.get("wrapperType") == "track":
                        found[str(x.get("trackId"))] = _apple_track(x)
            tr = []
            for n, i in enumerate(ids, 1):
                t = dict(found.get(i) or names[i])
                t["n"] = n
                tr.append(t)
            return ("list", _list_result(svc, "playlist", url, pl.get("name"), "", "", "", tr))

        if svc == "deezer":
            kind, did = g[0].lower(), g[1]
            def dz(x, alb=None):
                al = x.get("album") or alb or {}
                return {"title": x.get("title") or "", "artist": (x.get("artist") or {}).get("name") or "",
                        "album": al.get("title") or "", "duration": x.get("duration") or 0,
                        "cover": al.get("cover_xl") or al.get("cover_big") or "", "n": x.get("track_position") or 0,
                        "disc": x.get("disk_number") or 1, "year": str(x.get("release_date") or "")[:4]}
            if kind == "track":
                x = _json("https://api.deezer.com/track/" + did)
                if x.get("error"):
                    raise AppError("讀不到這首 Deezer 歌曲 (%s)" % (x["error"].get("message") or ""))
                t = dz(x)
                t["artist"] = ", ".join(c.get("name") for c in (x.get("contributors") or []) if c.get("name")) or t["artist"]
                return ("track", t)
            x = _json("https://api.deezer.com/%s/%s" % (kind, did))
            if x.get("error"):
                raise AppError("讀不到這個 Deezer %s" % ("專輯" if kind == "album" else "播放清單"))
            items = list((x.get("tracks") or {}).get("data") or [])
            nxt, guard = (x.get("tracks") or {}).get("next"), 0
            while nxt and guard < 20:  # 長清單分頁
                more = _json(nxt)
                items += more.get("data") or []
                nxt, guard = more.get("next"), guard + 1
            alb = x if kind == "album" else None
            tr = [dz(i, alb) for i in items]
            if kind == "album":
                for i, t in enumerate(tr, 1):
                    t["n"] = i
                    t["album"] = x.get("title") or ""
                    t["year"] = str(x.get("release_date") or "")[:4]
            else:
                for t in tr:
                    t["n"] = 0
            return ("list", _list_result(svc, kind, url, x.get("title"), ((x.get("artist") or {}).get("name") if kind == "album"
                                         else (x.get("creator") or {}).get("name")), x.get("cover_xl") or x.get("picture_xl"),
                                         str(x.get("release_date") or "")[:4], tr))

        if svc == "line":
            kind, lid = g[0].lower(), g[1]
            def find_tracks(o, out):
                if isinstance(o, dict):
                    if o.get("trackTitle"):
                        out.append(o)
                        return
                    for v in o.values():
                        find_tracks(v, out)
                elif isinstance(o, list):
                    for v in o:
                        find_tracks(v, out)
                return out
            def ln(x):
                al = x.get("album") or {}
                return {"title": x.get("trackTitle") or "", "artist": ", ".join(a.get("artistName") for a in (x.get("artists") or []) if a.get("artistName")),
                        "album": al.get("albumTitle") or "", "cover": al.get("imageUrl") or "", "n": x.get("trackNumber") or 0,
                        "disc": x.get("discNumber") or 1, "duration": round((x.get("playTime") or x.get("duration") or 0) / (1000 if (x.get("playTime") or 0) > 10000 else 1)),
                        "year": str(al.get("releaseDate") or "")[:4]}
            api = "https://music.line.me/api2/"
            if kind == "track":
                tr = find_tracks(_json(api + "tracks/%s.v1" % lid), [])
                if not tr:
                    raise AppError("讀不到這首 LINE MUSIC 歌曲")
                return ("track", ln(tr[0]))
            if kind == "album":
                info = (_json(api + "album/%s.v1" % lid).get("response") or {}).get("result") or {}
                info = info.get("album") or info
                tr = [ln(x) for x in find_tracks(_json(api + "album/%s/tracks.v1?start=1&display=1000" % lid), [])]
                return ("list", _list_result(svc, "album", url, info.get("albumTitle"),
                                             ", ".join(a.get("artistName") for a in (info.get("artists") or []) if a.get("artistName")),
                                             info.get("imageUrl"), str(info.get("releaseDate") or "")[:4], tr))
            data = _json(api + "playlist/%s.v2" % lid)
            res = (data.get("response") or {}).get("result") or {}
            plinfo = res.get("playlist") or res
            tr = [ln(x) for x in find_tracks(data, [])]
            for t in tr:
                t["n"] = 0
            return ("list", _list_result(svc, "playlist", url, plinfo.get("title") or plinfo.get("playlistTitle"),
                                         (plinfo.get("author") or {}).get("name") if isinstance(plinfo.get("author"), dict) else "",
                                         plinfo.get("imageUrl") or plinfo.get("thumbnailImageUrl"), "", tr))

        # TIDAL / Amazon Music: 讀取網頁附的公開資訊 (標題、歌手、封面)
        kind = g[0].lower().rstrip("s").replace("user-playlist", "playlist")
        if svc == "amazon" and g[2]:
            kind = "track"
        if kind == "playlist":
            raise AppError("%s 的播放清單目前不支援, 請改貼單曲或專輯連結" % site)
        page_url = url if svc == "amazon" else "https://tidal.com/%s/%s" % (kind, g[1])
        final, body = http_get(page_url, timeout=25)
        page = body.decode("utf-8", "replace")
        lds = _ld_json(page)
        rec = next((x for x in lds if x.get("@type") == "MusicRecording"), None)
        alb = next((x for x in lds if x.get("@type") == "MusicAlbum"), None)
        by = lambda x: ", ".join(a.get("name") for a in (x if isinstance(x, list) else [x]) if isinstance(a, dict) and a.get("name"))
        og_t, og_i = _meta_tag(page, "og:title"), _meta_tag(page, "og:image")
        if kind == "track":
            if rec:
                t = {"title": rec.get("name") or "", "artist": by(rec.get("byArtist")), "duration": _iso_dur(rec.get("duration")),
                     "cover": og_i, "album": (rec.get("inAlbum") or {}).get("name") if isinstance(rec.get("inAlbum"), dict) else "", "year": ""}
            else:  # 只有標題: 「歌手 - 歌名」或「歌名 by 歌手」
                m = re.match(r"(.+?)\s+-\s+(.+)", og_t) or None
                m2 = re.match(r"(.+?)\s+by\s+(.+?)(?:\s+on\s+.*)?$", og_t, re.I)
                t = {"title": m.group(2) if m else (m2.group(1) if m2 else og_t), "artist": m.group(1) if m else (m2.group(2) if m2 else ""),
                     "duration": 0, "cover": og_i, "album": "", "year": ""}
            if not t["title"]:
                raise AppError("讀不到這首 %s 歌曲的資訊" % site)
            return ("track", t)
        if kind == "album" and (alb or og_t):
            name = (alb or {}).get("name") or og_t
            artist = by((alb or {}).get("byArtist"))
            tr = itunes_album(artist, name)
            if tr:
                return ("list", _list_result(svc, "album", url, name, artist, (alb or {}).get("image") or og_i,
                                             str((alb or {}).get("datePublished") or "")[:4], tr))
            raise AppError("讀不到「%s」這張專輯的曲目, 可改貼單曲連結" % name)
        raise AppError("%s 的%s連結目前不支援, 請改貼單曲或專輯連結" % (site, "播放清單" if kind == "playlist" else ""))
    except AppError:
        raise
    except urllib.error.HTTPError as e:
        raise AppError("讀不到 %s 的資料 (HTTP %s), 連結可能失效或不公開" % (site, e.code))
    except Exception as e:
        log("analyze_music %s failed: %r" % (svc, e))
        raise AppError("讀不到 %s 的資料: %s" % (site, e))


def analyze_music_url(ref):
    svc, g, url = ref
    what, data = analyze_music(svc, g, url)
    if what == "list":
        return data
    t = data
    artists = [a.strip() for a in re.split(r"\s*,\s*|\s*&\s*", t.get("artist") or "") if a.strip()]
    meta = {"name": t["title"], "artists": artists, "duration": int(t.get("duration") or 0), "year": t.get("year") or "",
            "cover": t.get("cover") or "", "album": t.get("album") or ""}
    return match_track(meta, url, SITE_NAMES[svc])


def safe_filename(name):
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", str(name or "")).strip(" .")
    return name[:150].rstrip(" .") or "audio"


COVER_PPA = ("EmbedThumbnail+ffmpeg_o:-c:v mjpeg -qmin 1 -qmax 1 "
             "-vf crop=\"'if(gt(ih,iw),iw,ih)':'if(gt(iw,ih),ih,iw)'\"")


def find_idm():
    """找 Internet Download Manager 的 IDMan.exe; 沒裝回傳 None。"""
    cands = [os.environ.get("YTD_IDM")]
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\DownloadManager") as k:
                cands.append(str(winreg.QueryValueEx(k, "ExePath")[0]))
        except Exception:
            pass
        for env in ("ProgramFiles(x86)", "ProgramFiles"):
            base = os.environ.get(env)
            if base:
                cands.append(os.path.join(base, "Internet Download Manager", "IDMan.exe"))
    for c in cands:
        c = (c or "").strip().strip('"')
        if c.lower().endswith(".exe") and os.path.isfile(c):
            return c
    return None


def idm_handoff(url, out_dir, filename):
    """用 IDM 官方的命令列加入下載: IDMan.exe /d 網址 /p 資料夾 /f 檔名 /n (不詢問)。"""
    exe = find_idm()
    if not exe:
        raise AppError("找不到 Internet Download Manager, 請取消勾選「交給 IDM 下載」")
    cmd = [exe, "/d", url, "/p", out_dir.rstrip("\\/")]
    if filename:
        cmd += ["/f", filename]
    subprocess.Popen(cmd + ["/n"], cwd=out_dir)


# ----------------------------------------------------------------- 音量標準化 (MP3Gain)
# 優先用 mp3rgain (MP3Gain 的現代版, MIT 授權, 也支援 M4A); 沒有的話用電腦上的 mp3gain.exe。
# 兩者都是無損調整 (只改每個音框的增益值, 不重新編碼), 以 1.5 dB 為一級。
GAIN_REPO = "M-Igashi/mp3rgain"
GAIN_TARGETS = (89, 92, 95)
GAIN_LOCK = threading.Lock()


def find_gain_tool():
    """回傳 (執行檔, 是否為 mp3rgain); 都沒有回傳 (None, False)。"""
    t = tool("mp3rgain")
    if t:
        return t, True
    cands = [tool("mp3gain"), load_config().get("mp3gain_path")]
    for env in ("ProgramFiles(x86)", "ProgramFiles"):
        base = os.environ.get(env)
        if base:
            cands.append(os.path.join(base, "MP3Gain", "mp3gain.exe"))
    for c in cands:
        c = (c or "").strip().strip('"')
        if c and os.path.isfile(c):
            return c, False
    return None, False


def install_gain_tool():
    """從 mp3rgain 的 GitHub Releases 下載最新 Windows 版到 bin\\ (會比對官方提供的 SHA-256)。"""
    if not IS_WIN:
        raise AppError("自動下載音量工具只支援 Windows")
    with GAIN_LOCK:
        exe, _ = find_gain_tool()
        if exe and os.path.basename(exe).lower().startswith("mp3rgain"):
            return exe
        _, body = http_get("https://api.github.com/repos/%s/releases/latest" % GAIN_REPO, timeout=20, limit=1 << 21)
        rel = json.loads(body.decode("utf-8"))
        assets = {a.get("name"): a.get("browser_download_url") for a in rel.get("assets") or []}
        name = next((n for n in assets if re.fullmatch(r"mp3rgain-v[\d.]+-windows-x86_64\.zip", n or "")), None)
        if not name:
            raise AppError("找不到 mp3rgain 的 Windows 版下載檔")
        _, data = http_get(assets[name], timeout=120, limit=40 << 20)
        want = ""
        if assets.get(name + ".sha256"):
            _, sha = http_get(assets[name + ".sha256"], timeout=20, limit=4096)
            want = sha.decode("ascii", "replace").split()[0].lower()
        if want and hashlib.sha256(data).hexdigest() != want:
            raise AppError("mp3rgain 下載檔驗證失敗 (SHA-256 不符), 已取消")
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            member = next((n for n in z.namelist() if n.lower().endswith("mp3rgain.exe")), None)
            if not member:
                raise AppError("mp3rgain 下載檔內容不正確")
            os.makedirs(BIN, exist_ok=True)
            dst = os.path.join(BIN, "mp3rgain.exe")
            with open(dst + ".tmp", "wb") as f:
                f.write(z.read(member))
            os.replace(dst + ".tmp", dst)
        log("mp3rgain installed: %s" % rel.get("tag_name"))
        return dst


def gain_tool_name():
    exe, modern = find_gain_tool()
    return ("mp3rgain" if modern else "MP3Gain") if exe else ""


def apply_gain(paths, target, noclip):
    """把音量調到目標 (89 dB 為 ReplayGain 標準, 92 / 95 更大聲)。失敗不影響下載結果。"""
    exe, modern = find_gain_tool()
    if not exe:
        return "找不到音量工具 (mp3rgain / MP3Gain), 未調整音量"
    exts = (".mp3", ".m4a", ".aac", ".mp4") if modern else (".mp3",)
    files = [p for p in paths if p and os.path.isfile(p) and p.lower().endswith(exts)]
    if not files:
        return ""
    cmd = [exe, "-r", "-d", str(int(target) - 89)] + (["-k"] if noclip else []) + ["-c"] * (not modern)
    try:
        rc, _, err = run(cmd + files, timeout=max(120, 30 * len(files)))
    except Exception as e:
        rc, err = 1, repr(e)
    if rc != 0:
        log("apply_gain failed: %s" % (err or "")[-400:])
        return "音量調整失敗"
    return ""


def find_mp3tag():
    """找 Mp3tag (https://www.mp3tag.de/) 的安裝位置; 沒裝回傳 None。"""
    if os.name != "nt":
        return os.environ.get("YTD_MP3TAG") or None
    cands = [os.environ.get("YTD_MP3TAG")]
    try:
        import winreg
        for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            for key, val in ((r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Mp3tag.exe", None),
                             (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Mp3tag", "DisplayIcon"),
                             (r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Mp3tag", "DisplayIcon")):
                try:
                    with winreg.OpenKey(root, key) as k:
                        cands.append(str(winreg.QueryValueEx(k, val)[0] if val else winreg.QueryValue(k, None)))
                except OSError:
                    pass
    except Exception:
        pass
    for env in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        base = os.environ.get(env)
        if base:
            cands += [os.path.join(base, "Mp3tag", "Mp3tag.exe"), os.path.join(base, "Programs", "Mp3tag", "Mp3tag.exe")]
    for c in cands:
        c = (c or "").split(",")[0].strip().strip('"')
        if c.lower().endswith(".exe") and os.path.isfile(c):
            return c
    return None


# ----------------------------------------------------------------- 歌詞 (LRCLIB: 免費的公開歌詞資料庫)
LYRICS_API = "https://lrclib.net/api/search"


def fetch_lyrics(title, artist, duration):
    """回傳 (同步歌詞 LRC, 純文字歌詞); 找不到回傳 ("", "")。"""
    title = re.sub(r"\s*[\(\[（【].*?(official|mv|music video|lyric|audio|官方|歌詞|高畫質).*?[\)\]）】]", "", title, flags=re.I).strip()
    first = re.split(r"\s*[,&、]\s*|\s+feat\.?\s+", artist or "")[0].strip()
    q = "track_name=%s" % urllib.request.quote(title)
    if first:
        q += "&artist_name=%s" % urllib.request.quote(first)
    _, body = http_get(LYRICS_API + "?" + q, timeout=15, limit=4 << 20)
    best, best_d = None, 99999
    for x in json.loads(body.decode("utf-8", "replace")) or []:
        if not isinstance(x, dict) or x.get("instrumental") or not (x.get("syncedLyrics") or x.get("plainLyrics")):
            continue
        d = abs(float(x.get("duration") or 0) - duration) if duration else 0
        if x.get("syncedLyrics"):
            d -= 0.5  # 同長度時優先有時間軸的版本
        if d < best_d:
            best, best_d = x, d
    if not best or (duration and best_d > 6):
        return "", ""
    synced = str(best.get("syncedLyrics") or "")
    plain = str(best.get("plainLyrics") or "") or re.sub(r"^\[[\d:.]+\]\s?", "", synced, flags=re.M)
    return synced, plain


def _syncsafe(n):
    return bytes([(n >> 21) & 0x7F, (n >> 14) & 0x7F, (n >> 7) & 0x7F, n & 0x7F])


def write_uslt(path, text):
    """把歌詞寫成 ID3 的 USLT 欄位 (多數播放器與手機讀的是這個)。"""
    with open(path, "rb") as f:
        data = f.read()
    enc = lambda t: b"\xff\xfe" + t.encode("utf-16-le")
    body = b"\x01" + b"eng" + enc("") + b"\x00\x00" + enc(text)
    if data[:3] == b"ID3":
        ver, flags = data[3], data[5]
        if ver not in (3, 4) or flags & 0x40:
            raise ValueError("unsupported id3")
        size = (data[6] << 21) | (data[7] << 14) | (data[8] << 7) | data[9]
        frames, audio = data[10:10 + size], data[10 + size:]
        pos, kept = 0, b""
        while pos + 10 <= len(frames) and frames[pos:pos + 4] != b"\x00\x00\x00\x00":
            fs = frames[pos + 4:pos + 8]
            n = ((fs[0] << 21) | (fs[1] << 14) | (fs[2] << 7) | fs[3]) if ver == 4 else int.from_bytes(fs, "big")
            if frames[pos:pos + 4] != b"USLT":
                kept += frames[pos:pos + 10 + n]
            pos += 10 + n
        fsize = _syncsafe(len(body)) if ver == 4 else len(body).to_bytes(4, "big")
        new = kept + b"USLT" + fsize + b"\x00\x00" + body
        tag = b"ID3" + bytes([ver, 0, 0]) + _syncsafe(len(new)) + new
    else:
        ver, audio = 3, data
        new = b"USLT" + len(body).to_bytes(4, "big") + b"\x00\x00" + body
        tag = b"ID3\x03\x00\x00" + _syncsafe(len(new)) + new
    tmp = path + ".lyr_tmp"
    with open(tmp, "wb") as f:
        f.write(tag + audio)
    os.replace(tmp, path)


def read_audio_info(path):
    """讀取音訊檔的歌名、歌手與長度。"""
    probe = tool("ffprobe")
    info = {"title": "", "artist": "", "duration": 0}
    if not probe:
        return info
    rc, out, _ = run([probe, "-v", "error", "-show_entries", "format=duration:format_tags=title,artist",
                      "-of", "json", path], timeout=60)
    if rc == 0:
        fmt = (json.loads(out or "{}").get("format") or {})
        tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}
        info.update(title=tags.get("title", ""), artist=tags.get("artist", ""), duration=float(fmt.get("duration") or 0))
    return info


def add_lyrics(paths, tags=None):
    """下載歌詞: 寫入 MP3 / M4A 的歌詞欄位, 並在同一個資料夾存一份 .lrc (有時間軸, 播放器會逐句顯示)。"""
    found = 0
    for p in paths:
        ext = os.path.splitext(p or "")[1].lower()
        if ext not in (".mp3", ".m4a") or not os.path.isfile(p):
            continue
        try:
            info = read_audio_info(p)
            title = (tags or {}).get("title") or info["title"] or os.path.splitext(os.path.basename(p))[0]
            artist = (tags or {}).get("artist") or info["artist"]
            if not artist and " - " in title:
                artist, title = [x.strip() for x in title.split(" - ", 1)]
            synced, plain = fetch_lyrics(title, artist, info["duration"])
            if not plain:
                continue
            if synced:
                with open(os.path.splitext(p)[0] + ".lrc", "w", encoding="utf-8") as f:
                    f.write(synced)
            if ext == ".mp3":
                write_uslt(p, plain)
            else:
                ff = tool("ffmpeg")
                out = os.path.join(os.path.dirname(p), "~ytd_tmp_%d%s" % (time.time_ns(), ext))
                rc, _, _ = run([ff, "-y", "-loglevel", "error", "-i", p, "-map", "0", "-c", "copy",
                                "-metadata", "lyrics=" + plain, out], timeout=300)
                if rc == 0 and os.path.isfile(out):
                    os.replace(out, p)
                elif os.path.isfile(out):
                    os.remove(out)
            found += 1
        except Exception as e:
            log("lyrics failed for %s: %r" % (os.path.basename(p or ""), e))
    return found


def tag_audio(path, post):
    """用 ffmpeg 寫入歌名/歌手與 Spotify 封面 (不重新編碼)。"""
    ff = tool("ffmpeg")
    if not ff or not path or not os.path.isfile(path):
        return
    ext = os.path.splitext(path)[1].lower()
    cover = None
    url = post.get("cover") or ""
    if not url and post.get("sp_id"):  # 播放清單的歌曲: 各自讀取專輯封面
        try:
            meta = spotify_meta(post["sp_id"])
            url = meta.get("cover") or ""
            if meta.get("year") and not (post.get("tags") or {}).get("date"):
                post.setdefault("tags", {})["date"] = meta["year"]
        except Exception as e:
            log("spotify track meta failed: %r" % e)
    host = urllib.request.urlparse(url).hostname or ""
    if url.startswith("https://") and host.endswith((".scdn.co", ".spotifycdn.com", ".mzstatic.com", ".dzcdn.net",
                                                     "resources.tidal.com", ".line-scdn.net", ".media-amazon.com", ".ssl-images-amazon.com")):
        try:
            _, data = http_get(url)
            if len(data) > 1000:
                cover = os.path.join(TMP, "cover_%d.jpg" % time.time_ns())
                with open(cover, "wb") as f:
                    f.write(data)
        except Exception as e:
            log("cover download failed: %r" % e)

    def build(with_cover):
        cmd = [ff, "-y", "-loglevel", "error", "-i", path]
        # 沒拿到 Spotify 封面時保留下載核心已嵌入的 (裁成正方形的) 縮圖
        cmd += ["-i", cover, "-map", "0:a", "-map", "1:v"] if with_cover else ["-map", "0"]
        cmd += ["-c", "copy"]
        for k in ("title", "artist", "album", "date", "track", "album_artist"):
            v = str((post.get("tags") or {}).get(k) or "")[:300]
            if v:
                cmd += ["-metadata", "%s=%s" % (k, v)]
        if ext == ".mp3":
            cmd += ["-id3v2_version", "3"]
            if with_cover:
                cmd += ["-metadata:s:v", "title=Album cover", "-metadata:s:v", "comment=Cover (front)"]
        elif with_cover:
            cmd += ["-disposition:v:0", "attached_pic"]
        return cmd

    out = os.path.join(os.path.dirname(path), "~ytd_tmp_%d%s" % (time.time_ns(), ext))
    try:
        for with_cover in ([True, False] if cover else [False]):
            try:
                rc, _, err = run(build(with_cover) + [out], timeout=300)
            except Exception as e:
                rc, err = 1, repr(e)
            if rc == 0 and os.path.isfile(out) and os.path.getsize(out) > 0:
                os.replace(out, path)
                break
            log("tag_audio failed (cover=%s): %s" % (with_cover, err[-300:]))
    finally:
        for f in (out, cover):
            if f and os.path.isfile(f):
                try:
                    os.remove(f)
                except Exception:
                    pass


def stream_url(url):
    """備援預覽: 取得可直接播放的串流網址。"""
    url = check_url(url)
    rc, out, err = run(
        [tool("yt-dlp"), "-g", "--no-playlist", "--no-warnings", "--playlist-items", "1"]
        + cookie_args(url) +
        ["-f", "b[ext=mp4][height<=720]/b[height<=720]/b", "--", url], timeout=90)
    lines = [l for l in out.splitlines() if l.startswith("http")]
    if rc != 0 or not lines:
        raise AppError(friendly_error(last_error(err), url) if rc != 0 else "此影片沒有可直接預覽的串流")
    return lines[0]


# ----------------------------------------------------------------- Instagram 限時動態 (內建讀取)
# yt-dlp 目前對限時動態失效; 這裡改成像瀏覽器一樣開啟限時動態頁面 (帶使用者自己匯入的 cookies),
# 直接讀取頁面裡附帶的影片/照片位址。
IG_STORY_RE = re.compile(r"^https?://(?:www\.)?instagram\.com/stories/([A-Za-z0-9._]+)(?:/(\d+))?", re.I)
IG_KEY = "xdt_api__v1__feed__reels_media"


def cookie_header(host):
    pairs = {}
    with open(COOKIE_FILE, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if line.startswith("#HttpOnly_"):
                line = line[len("#HttpOnly_"):]
            elif line.startswith("#") or not line.strip():
                continue
            p = line.rstrip("\r\n").split("\t")
            if len(p) < 7:
                continue
            dom = p[0].lstrip(".").lower()
            if host != dom and not host.endswith("." + dom):
                continue
            if p[4].isdigit() and 0 < int(p[4]) < time.time():
                continue
            pairs[p[5]] = p[6]
    return "; ".join("%s=%s" % kv for kv in pairs.items())


def ig_fetch(url, with_cookies=True):
    """以瀏覽器開啟網頁的方式讀取頁面; 回傳 (最終網址, HTML)。"""
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-TW,zh;q=0.9,en;q=0.8",
        "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1", "Upgrade-Insecure-Requests": "1",
        "sec-ch-ua": '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
        "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
    })
    if with_cookies and os.path.isfile(COOKIE_FILE):
        host = (urllib.request.urlparse(url).hostname or "").lower()
        req.add_header("Cookie", cookie_header(host if host.endswith("threads.com") else "www.instagram.com"))
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.geturl(), r.read(12 << 20).decode("utf-8", "replace")


def find_key(obj, key):
    stack = [obj]
    while stack:
        o = stack.pop()
        if isinstance(o, dict):
            if key in o:
                return o[key]
            stack.extend(o.values())
        elif isinstance(o, list):
            stack.extend(o)
    return None


def ig_story(url, username, story_id):
    st = cookie_summary()["instagram"]
    if st != "ok":
        why = {"expired": "YTD 裡的 Instagram 登入資料已過期",
               "nologin": "YTD 裡有 Instagram 的資料, 但不是登入狀態 (可能登入沒有完成)",
               "none": "YTD 裡還沒有 Instagram 的登入資料"}.get(st, "沒有登入資料")
        mode = load_config().get("login_mode")
        tip = ""
        if mode in BROWSERS:
            tip = " (目前登入方式是「從 %s 讀取」, 這個方式讀不到限時動態)" % mode
        raise AppError("下載 Instagram 限時動態需要登入: %s%s。\n請到右上角「登入設定」按「登入 Instagram」, "
                       "在跳出的視窗登入, 看到 Instagram 首頁後視窗會自動關閉, 再貼一次網址。"
                       "(在自己的 Chrome 登入 Instagram 不算, 要在 YTD 開的視窗登入一次)" % (why, tip))
    page_url = "https://www.instagram.com/stories/%s/" % username + ("%s/" % story_id if story_id else "")
    try:
        final, page = ig_fetch(page_url)
    except Exception as e:
        raise AppError("無法開啟 Instagram 限時動態頁面: %s" % e)
    if "/accounts/login" in final or "/challenge" in final:
        raise AppError("Instagram 要求重新登入 (登入資料已失效或需要驗證)。請到右上角「登入設定」再按一次「登入 Instagram」。")
    data = None
    for m in re.finditer(r'<script type="application/json"[^>]*>(.*?)</script>', page, re.S):
        if IG_KEY in m.group(1):
            try:
                data = find_key(json.loads(m.group(1)), IG_KEY)
            except Exception as e:
                log("ig_story json failed: %r" % e)
            if data:
                break
    if not isinstance(data, dict):
        log("ig_story: no data, final=%s len=%d key=%s login=%s" % (
            final, len(page), IG_KEY in page, '"is_logged_in":true' in page or "ds_user_id" in page))
        raise AppError("已開啟 Instagram 頁面 (%d KB), 但裡面沒有限時動態的資料。可能是 Instagram 沒有把這次連線當成瀏覽器, "
                       "或頁面格式已改版。請把這段訊息回報給 Claude。" % (len(page) // 1024))
    reels = [r for r in (data.get("reels_media") or []) if isinstance(r, dict)]
    items = [it for r in reels for it in (r.get("items") or []) if isinstance(it, dict)]
    if not items:
        raise AppError("這個帳號目前沒有你看得到的限時動態 (可能已過期, 或對方沒有發佈)。")
    if story_id:
        only = [it for it in items if str(it.get("pk")) == story_id or str(it.get("id", "")).split("_")[0] == story_id]
        if not only:
            raise AppError("找不到這一則限時動態, 可能已經過期。可改貼 instagram.com/stories/%s/ 下載目前所有的限時動態。" % username)
        items = only
    user = (reels[0].get("user") or {}) if reels else {}
    uname = user.get("username") or username
    direct = ig_direct(items, uname, "story")
    if not direct:
        raise AppError("限時動態裡沒有可下載的影片或照片。")
    return ig_result(url, "%s 的限時動態" % uname, uname, direct, "限時動態")


def ig_direct(items, username, fallback):
    name = safe_filename(username)
    direct = []
    many = len(items) > 1 and fallback != "story"
    for n, it in enumerate(items, 1):
        imgs = [c for c in ((it.get("image_versions2") or {}).get("candidates") or []) if isinstance(c, dict) and c.get("url")]
        # 候選清單含裁成正方形的版本; 取面積最大者才是原始比例
        thumb = max(imgs, key=lambda c: (c.get("width") or 0) * (c.get("height") or 0))["url"] if imgs else ""
        vids = [v for v in (it.get("video_versions") or []) if isinstance(v, dict) and v.get("url")]
        taken = int(it.get("taken_at") or 0)
        stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(taken)) if taken else fallback
        when = time.strftime("%m/%d %H:%M", time.localtime(taken)) if taken else ""
        tail = "_%02d" % n if many else ""
        if vids:
            dur = int(round(it.get("video_duration") or 0))
            direct.append({"url": vids[0]["url"], "kind": "video", "mime": "video/mp4", "duration": dur,
                           "thumb": thumb, "label": ("影片 · " + when).rstrip(" ·"),
                           "filename": "%s_%s%s.mp4" % (name, stamp, tail)})
        elif thumb:
            ext = os.path.splitext(urllib.request.urlparse(thumb).path)[1].lower()
            ext = ext if ext in (".jpg", ".jpeg", ".png", ".webp", ".heic") else ".jpg"
            direct.append({"url": thumb, "kind": "photo", "mime": "image/jpeg", "duration": 0,
                           "thumb": thumb, "label": ("照片 · " + when).rstrip(" ·"),
                           "filename": "%s_%s%s%s" % (name, stamp, tail, ext)})
    return direct


def ig_result(url, title, uploader, direct, noun, note="", site="Instagram"):
    return {
        "source": "igstory", "url": url, "id": "", "youtube_id": "", "title": title,
        "uploader": uploader, "duration": 0, "view_count": None,
        "upload_date": "", "is_live": False, "thumbnail": direct[0]["thumb"], "site": site,
        "qualities": [], "audio_size": 0, "count": len(direct), "direct": direct, "noun": noun, "note": note,
    }


# ----------------------------------------------------------------- X (Twitter) 貼文
# 用 X 嵌入推文用的公開資料 (不用登入): 影片取最高畫質、照片取原始尺寸、GIF 取 MP4。
X_RE = re.compile(r"^https?://(?:www\.|mobile\.)?(?:x|twitter|fxtwitter|vxtwitter|fixupx|fixvx)\.com/(?:([A-Za-z0-9_]+)|i(?:/web)?)/status(?:es)?/(\d+)", re.I)


def _x_token(tid):
    """與 X 官方嵌入程式相同的驗證碼算法: (id / 1e15 * π) 轉 36 進位 (最短位數) 後去掉 0 與小數點。"""
    v = int(tid) / 1e15 * math.pi
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"

    def b36(n):
        out = ""
        while n:
            n, r = divmod(n, 36)
            out = digits[r] + out
        return out or "0"

    ip = int(v)
    frac = ""
    for k in range(1, 40):  # 取最短、且換算回來數值相同的小數位數 (與 JavaScript 的 toString(36) 一致)
        f = round((v - ip) * 36 ** k)
        if ip + f / 36 ** k == v:
            frac = b36(f).rjust(k, "0")
            break
    return re.sub(r"0+|\.", "", b36(ip) + "." + frac)


def x_post(url, tid):
    try:
        _, body = http_get("https://cdn.syndication.twimg.com/tweet-result?id=%s&token=%s&lang=zh-tw" % (tid, _x_token(tid)),
                           timeout=20, limit=4 << 20)
        t = json.loads(body.decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        raise AppError("讀不到這則 X 貼文 (HTTP %s)" % e.code)
    except Exception as e:
        raise AppError("無法讀取 X 貼文: %s" % e)
    if not isinstance(t, dict) or t.get("__typename") not in (None, "Tweet"):
        raise AppError("這則 X 貼文不公開或需要登入")
    medias = t.get("mediaDetails") or []
    owner = t
    if not medias and isinstance(t.get("quoted_tweet"), dict):  # 本身沒有圖片影片: 看引用的貼文
        owner = t["quoted_tweet"]
        medias = owner.get("mediaDetails") or []
    if not medias:
        raise AppError("這則 X 貼文沒有照片或影片")
    user = ((owner.get("user") or {}).get("screen_name") or "x").strip()
    try:
        when = datetime.datetime.fromisoformat(str(owner.get("created_at")).replace("Z", "+00:00")).astimezone()
        stamp, label_t = when.strftime("%Y%m%d_%H%M%S"), when.strftime(" · %m/%d %H:%M")
    except Exception:
        stamp, label_t = str(tid), ""
    name = safe_filename(user)
    direct = []
    for n, m in enumerate(medias, 1):
        tail = "_%02d" % n if len(medias) > 1 else ""
        thumb = m.get("media_url_https") or ""
        if m.get("type") in ("video", "animated_gif"):
            vs = [v for v in ((m.get("video_info") or {}).get("variants") or [])
                  if v.get("content_type") == "video/mp4" and v.get("url")]
            if not vs:
                continue
            best = max(vs, key=lambda v: v.get("bitrate") or 0)
            gif = m.get("type") == "animated_gif"
            direct.append({"url": best["url"], "kind": "video", "mime": "video/mp4", "thumb": thumb,
                           "duration": round(((m.get("video_info") or {}).get("duration_millis") or 0) / 1000),
                           "label": ("GIF" if gif else "影片") + label_t, "filename": "%s_%s%s.mp4" % (name, stamp, tail)})
        elif thumb:
            path = urllib.request.urlparse(thumb).path
            ext = os.path.splitext(path)[1].lower() or ".jpg"
            base = thumb.split("?")[0]
            direct.append({"url": base + "?name=orig", "kind": "photo", "mime": mimetypes.guess_type("a" + ext)[0] or "image/jpeg",
                           "thumb": base + "?name=small", "duration": 0, "label": "照片" + label_t,
                           "filename": "%s_%s%s%s" % (name, stamp, tail, ext)})
    if not direct:
        raise AppError("這則 X 貼文沒有可下載的照片或影片")
    text = re.sub(r"\s*https://t\.co/\S+", "", str(owner.get("text") or "")).strip()
    note = "這則貼文本身沒有照片或影片, 下載的是它引用的貼文 (@%s)。" % user if owner is not t else ""
    return ig_result(url, (text[:80] or "@%s 的貼文" % user), user, direct, "貼文", note, site="X")


# ----------------------------------------------------------------- Instagram 貼文 (照片 / 多張貼文)
# 下載核心只支援影片; 貼文裡的照片改由這裡像瀏覽器一樣開啟貼文頁面讀取。
IG_POST_RE = re.compile(r"^https?://(?:www\.)?instagram\.com/(?:[A-Za-z0-9._]+/)?(p|reel|reels|tv)/([A-Za-z0-9_-]+)", re.I)
IG_POST_KEY = "xdt_api__v1__media__shortcode__web_info"


def ig_post(url, kind, code):
    logged = cookie_summary()["instagram"] == "ok"
    try:
        final, page = ig_fetch("https://www.instagram.com/p/%s/" % code, logged)
    except Exception as e:
        raise AppError("無法開啟 Instagram 貼文頁面: %s" % e)
    if "/accounts/login" in final or "/challenge" in final:
        raise AppError("這則貼文需要登入才能看 (私人帳號或 Instagram 要求登入)。請到右上角「登入設定」按「登入 Instagram」後再試。"
                       if not logged else "Instagram 要求重新登入, 儲存的登入資料已失效。請到右上角「登入設定」重新登入 Instagram。")
    data = None
    for m in re.finditer(r'<script type="application/json"[^>]*>(.*?)</script>', page, re.S):
        if IG_POST_KEY in m.group(1):
            try:
                data = find_key(json.loads(m.group(1)), IG_POST_KEY)
            except Exception as e:
                log("ig_post json failed: %r" % e)
            if data:
                break
    items = [it for it in ((data or {}).get("items") or []) if isinstance(it, dict)] if isinstance(data, dict) else []
    if items:
        it = items[0]
        uname = (it.get("user") or {}).get("username") or "instagram"
        parts = [c for c in (it.get("carousel_media") or []) if isinstance(c, dict)] or [it]
        for c in parts:
            c.setdefault("taken_at", it.get("taken_at"))
        direct = ig_direct(parts, uname, code)
        if direct:
            return ig_result(url, "%s 的貼文" % uname, uname, direct, "貼文")
    # 頁面沒有附完整資料 (通常是未登入): 退而使用頁面標示的封面圖
    og = _meta_tag(page, "og:image")
    if og and kind.lower() == "p":
        log("ig_post: fallback og:image, logged=%s len=%d" % (logged, len(page)))
        ext = os.path.splitext(urllib.request.urlparse(og).path)[1].lower()
        ext = ext if ext in (".jpg", ".jpeg", ".png", ".webp") else ".jpg"
        who = re.search(r"\(@([A-Za-z0-9._]+)\)", _meta_tag(page, "og:title") + " " + _meta_tag(page, "og:description"))
        d = [{"url": og, "kind": "photo", "mime": "image/jpeg", "duration": 0, "thumb": og, "label": "照片 (封面)",
              "filename": "%s_%s%s" % (who.group(1) if who else "instagram", code, ext)}]
        return ig_result(url, "Instagram 貼文", "", d, "貼文",
                         "目前只取得第一張圖 (可能不是原始尺寸)。到右上角「登入設定」登入 Instagram 後, 可下載貼文裡的全部照片與原始尺寸。")
    raise AppError("讀不到這則貼文的內容。" + ("" if logged else "請到右上角「登入設定」登入 Instagram 後再試。"))


# ----------------------------------------------------------------- Threads 貼文
# 下載核心不支援 Threads。Threads 和 Instagram 同一套資料格式: 像瀏覽器一樣開啟貼文頁面,
# 頁面附帶的資料裡就有影片 / 照片 / 多張貼文的位址 (只有「開啟頁面」的請求才會附上完整資料)。
THREADS_RE = re.compile(r"^https?://(?:www\.)?threads\.(?:com|net)/(?:@([A-Za-z0-9._]+)/post|t)/([A-Za-z0-9_-]+)", re.I)


def _threads_medias(page):
    out = []
    for m in re.finditer(r'<script type="application/json"[^>]*>(.*?)</script>', page, re.S):
        body = m.group(1)
        if "video_versions" not in body and "image_versions2" not in body:
            continue
        try:
            stack = [json.loads(body)]
        except Exception as e:
            log("threads json failed: %r" % e)
            continue
        while stack:
            o = stack.pop()
            if isinstance(o, dict):
                md = o.get("media") if isinstance(o.get("media"), dict) else (o.get("post") if isinstance(o.get("post"), dict) else None)
                if md and md.get("code"):
                    out.append(md)
                stack.extend(o.values())
            elif isinstance(o, list):
                stack.extend(o)
    return out


SHARE_RE = re.compile(r"^https?://(?:www\.)?(?:threads\.(?:com|net)|instagram\.com)/share/", re.I)


def resolve_share(url):
    """Threads / Instagram 的分享短網址 (…/share/xxxx) 會跳轉到貼文本身的網址; 先找出原始網址。"""
    try:
        final, page = ig_fetch(url, True)
    except Exception as e:
        raise AppError("無法開啟分享連結: %s" % e)
    if not SHARE_RE.match(final) and "/login" not in final:
        return final
    for key in ("og:url",):
        v = _meta_tag(page, key)
        if v and not SHARE_RE.match(v):
            return htmllib.unescape(v)
    m = re.search(r'<link rel="canonical" href="([^"]+)"', page)
    if m and not SHARE_RE.match(htmllib.unescape(m.group(1))):
        return htmllib.unescape(m.group(1))
    raise AppError("無法從分享連結找到原本的貼文, 請在 App 裡按「複製連結」改貼貼文網址。")


def threads_post(url, user, code):
    logged = cookie_summary()["threads"] == "ok"
    page_url = "https://www.threads.com/@%s/post/%s" % (user, code) if user else "https://www.threads.com/t/%s" % code
    try:
        final, page = ig_fetch(page_url, logged)
    except Exception as e:
        raise AppError("無法開啟 Threads 貼文頁面: %s" % e)
    need_login = ("這則 Threads 貼文只開放特定對象查看 (或需要登入)。請到右上角「登入設定」按「登入 Threads」, "
                  "用看得到這則貼文的帳號登入後再試。")
    if "/login" in final:
        raise AppError(need_login if not logged else "Threads 要求重新登入, 請到右上角「登入設定」再按一次「登入 Threads」。")
    medias = _threads_medias(page)
    md = next((x for x in medias if x.get("code") == code), None)
    if md:
        uname = (md.get("user") or {}).get("username") or user or "threads"
        # 貼文本身的照片/影片; 沒有的話, 看它嵌入的影片 (例如分享的 IG Reels) 或引用/轉發的貼文
        tpai = md.get("text_post_app_info") or {}
        share = tpai.get("share_info") or {}
        cands = [(md, "", "")]
        lim = tpai.get("linked_inline_media")
        if isinstance(lim, dict):
            src = ((tpai.get("link_preview_attachment") or {}).get("display_url") or "").replace("instagram.com", "Instagram")
            cands.append((lim, "嵌入的 %s影片" % (src + " " if src else ""), (lim.get("code") or "")))
        for k, word in (("quoted_post", "引用的貼文"), ("reposted_post", "轉發的貼文")):
            if isinstance(share.get(k), dict):
                cands.append((share[k], word, share[k].get("code") or ""))
        for m, word, sub in cands:
            owner = (m.get("user") or {}).get("username") or uname
            parts = [c for c in (m.get("carousel_media") or []) if isinstance(c, dict)] or [m]
            for c in parts:
                c.setdefault("taken_at", m.get("taken_at") or md.get("taken_at"))
            direct = ig_direct(parts, owner, sub or code)
            if direct:
                note = ""
                if word:
                    note = "這則貼文本身只有文字, 下載的是它%s (@%s)。" % (word, owner)
                return ig_result(url, "%s 的 Threads 貼文" % uname, owner, direct, "貼文", note, site="Threads")
        raise AppError("這則 Threads 貼文只有文字, 沒有照片或影片可以下載。")
    og = _meta_tag(page, "og:image")
    title = _meta_tag(page, "og:title")
    log("threads_post: no media data, logged=%s len=%d og=%s" % (logged, len(page), bool(og)))
    if og and title:
        ext = os.path.splitext(urllib.request.urlparse(og).path)[1].lower()
        ext = ext if ext in (".jpg", ".jpeg", ".png", ".webp") else ".jpg"
        who = re.search(r"@([A-Za-z0-9._]+)", title)
        uname = who.group(1) if who else (user or "threads")
        d = [{"url": og, "kind": "photo", "mime": "image/jpeg", "duration": 0, "thumb": og, "label": "照片 (封面)",
              "filename": "%s_%s%s" % (uname, code, ext)}]
        return ig_result(url, "%s 的 Threads 貼文" % uname, uname, d, "貼文",
                         "只取得封面圖 (Threads 這次沒有附上完整資料)。登入 Threads 後再試, 通常就能下載影片與全部照片。",
                         site="Threads")
    raise AppError(need_login if not logged else "讀不到這則 Threads 貼文的內容, 可能已被刪除或只開放特定對象查看。")


# ----------------------------------------------------------------- 一般檔案 (多線程 / 續傳)
CHUNK = 4 << 20
THREADS = 8
HTML_TYPES = ("text/html", "application/xhtml+xml")
STREAM_TYPES = ("application/vnd.apple.mpegurl", "application/x-mpegurl", "application/dash+xml")


def filename_from(disp, url, ctype):
    name = ""
    m = re.search(r"filename\*\s*=\s*([\w-]*)''([^;]+)", disp or "", re.I)
    if m:
        try:
            name = urllib.request.unquote(m.group(2).strip(), encoding=m.group(1) or "utf-8")
        except Exception:
            name = ""
    if not name:
        m = re.search(r'filename\s*=\s*"([^"]+)"', disp or "", re.I) or \
            re.search(r"filename\s*=\s*([^;]+)", disp or "", re.I)
        if m:
            name = m.group(1).strip()
            try:  # 標頭以 latin-1 解讀, 實際常是 UTF-8
                name = name.encode("latin-1").decode("utf-8")
            except Exception:
                pass
    if not name:
        path = urllib.request.urlparse(url).path
        name = urllib.request.unquote(path.rstrip("/").rsplit("/", 1)[-1])
    name = os.path.basename(name.replace("\\", "/"))
    base, ext = os.path.splitext(name)
    ext = re.sub(r"[^A-Za-z0-9.]", "", ext)[:12]
    if not ext:
        ext = mimetypes.guess_extension(ctype or "") or ""
    return safe_filename(base or "download")[:140] + ext


def probe_file(url):
    """判斷網址是不是可直接下載的檔案; 是的話回傳檔案資訊, 否則回傳 None。"""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Range": "bytes=0-0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            ctype = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            disp = r.headers.get("Content-Disposition") or ""
            if ctype in HTML_TYPES and "attachment" not in disp.lower():
                return None
            if ctype in STREAM_TYPES:
                return None
            total, ranges = 0, False
            if r.status == 206:
                m = re.search(r"/(\d+)\s*$", r.headers.get("Content-Range") or "")
                if m:
                    total, ranges = int(m.group(1)), True
            else:
                total = int(r.headers.get("Content-Length") or 0)
            final = r.geturl()
    except Exception:
        return None
    name = filename_from(disp, final, ctype)
    return {
        "source": "file", "url": url, "id": "", "youtube_id": "", "title": name, "filename": name,
        "uploader": "", "duration": 0, "view_count": None, "upload_date": "", "thumbnail": "",
        "is_live": False, "site": urllib.request.urlparse(final).hostname or "",
        "qualities": [], "audio_size": 0, "size": total, "resumable": ranges, "mime": ctype,
    }


def pick_target(out_dir, name, url):
    path = os.path.join(out_dir, name)
    meta = read_json(path + ".part.json", {})
    if meta.get("url") == url and os.path.isfile(path + ".part"):
        return path  # 接續上次未完成的下載
    base, ext = os.path.splitext(name)
    i = 1
    while os.path.exists(path) or os.path.exists(path + ".part"):
        path = os.path.join(out_dir, "%s (%d)%s" % (base, i, ext))
        i += 1
    return path


def run_file_job(job):
    url = job["url"]
    job["status"], job["stage"], job["error"] = "downloading", "連線中", ""
    info = probe_file(url)
    if not info:
        job["status"], job["stage"] = "error", "失敗"
        job["error"] = "無法連線到檔案來源, 連結可能已失效"
        return
    total, ranges = info["size"], info["resumable"] and info["size"] > 0
    if not job.get("final"):
        job["final"] = pick_target(job["dir"], job["filename"], url)
    final = job["final"]
    part, meta = final + ".part", final + ".part.json"
    lock = threading.Lock()
    st = {"bytes": 0, "err": ""}

    def halted():
        return job["cancel"] or job["pause"]

    def fetch(start, end, f, prog):
        """下載一段資料寫入 f; prog[0] 累計已寫入的位元組數 (中斷時也保留)。"""
        headers = {"User-Agent": UA}
        if end is not None:
            headers["Range"] = "bytes=%d-%d" % (start, end)
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=30) as r:
            if end is not None and r.status != 206:
                raise OSError("伺服器不支援分段下載")
            f.seek(start)
            while not halted():
                b = r.read(65536)
                if not b:
                    break
                f.write(b)
                prog[0] += len(b)
                with lock:
                    st["bytes"] += len(b)

    done, partial = set(), {}
    if ranges:
        n = (total + CHUNK - 1) // CHUNK
        state = read_json(meta, {})
        if state.get("url") == url and state.get("total") == total and state.get("chunk") == CHUNK \
                and os.path.isfile(part) and os.path.getsize(part) == total:
            done = set(i for i in state.get("done", []) if isinstance(i, int) and 0 <= i < n)
            for k, v in (state.get("partial") or {}).items():
                if str(k).isdigit() and int(k) < n and int(k) not in done and isinstance(v, int) and 0 < v < CHUNK:
                    partial[int(k)] = v
        else:
            with open(part, "wb") as f:
                f.truncate(total)
        pending = collections.deque(i for i in range(n) if i not in done)
        st["bytes"] = sum(min(total, (i + 1) * CHUNK) - i * CHUNK for i in done) + sum(partial.values())

        def save_state():
            with lock:
                d, pt = sorted(done), {str(k): v for k, v in partial.items()}
            write_json(meta, {"url": url, "total": total, "chunk": CHUNK, "done": d, "partial": pt})

        def worker():
            with open(part, "r+b") as f:
                while not halted() and not st["err"]:
                    with lock:
                        if not pending:
                            return
                        i = pending.popleft()
                        off = partial.pop(i, 0)
                    start, end = i * CHUNK, min(total, (i + 1) * CHUNK) - 1
                    for attempt in range(6):
                        prog, err = [0], None
                        try:
                            fetch(start + off, end, f, prog)
                        except Exception as e:
                            err = e
                        off += prog[0]
                        f.flush()
                        if start + off > end:
                            with lock:
                                done.add(i)
                            break
                        if halted() or attempt == 5:  # 保留這一段已下載的進度, 之後從中斷處接續
                            with lock:
                                partial[i] = off
                                if not halted():
                                    st["err"] = str(err or "資料不完整")
                            return
                        time.sleep(1 + attempt)

        nthreads = max(1, min(THREADS, len(pending)))
        job["label"] = "檔案 · %d 線程" % nthreads
        save_state()
    else:
        nthreads = 1
        job["label"] = "檔案 · 單線程"

        def worker():
            try:
                with open(part, "wb") as f:
                    fetch(0, None, f, [0])
            except Exception as e:
                if not halted():
                    st["err"] = str(e)

    threads = [threading.Thread(target=worker, daemon=True) for _ in range(nthreads)]
    for t in threads:
        t.start()
    job["stage"] = "下載中"
    last_b, last_t, speed, saved = st["bytes"], time.time(), 0.0, time.time()
    while any(t.is_alive() for t in threads):
        time.sleep(0.5)
        now, b = time.time(), st["bytes"]
        inst = max(0.0, (b - last_b) / max(now - last_t, 0.001))
        speed = inst if not speed else speed * 0.7 + inst * 0.3
        last_b, last_t = b, now
        job["speed"] = speed
        if total:
            job["percent"] = max(0.0, min(100.0, b * 100.0 / total))
            job["eta"] = (total - b) / speed if speed > 1 else None
        if ranges and now - saved > 2:
            save_state()
            saved = now
    job["speed"] = job["eta"] = None
    if ranges:
        save_state()

    def cleanup():
        for p in (part, meta):
            try:
                os.remove(p)
            except Exception:
                pass

    complete = (len(done) == n) if ranges else (not st["err"] and not halted()
                                                and (not total or st["bytes"] == total))
    if job["cancel"]:
        cleanup()
        job["status"], job["stage"] = "canceled", "已取消"
    elif job["pause"]:
        job["status"] = "paused"
        job["stage"] = "已暫停" if ranges else "已暫停 (此來源不支援續傳, 繼續時會重新下載)"
    elif complete:
        try:
            os.replace(part, final)
        except Exception as e:
            job["status"], job["stage"], job["error"] = "error", "失敗", "無法寫入檔案: %s" % e
            return
        try:
            os.remove(meta)
        except Exception:
            pass
        job["status"], job["stage"], job["percent"] = "done", "完成", 100.0
        job["file"] = final
    else:
        job["status"], job["stage"] = "error", "失敗"
        job["error"] = "下載中斷: %s (按「重試」可從中斷處繼續)" % (st["err"] or "資料不完整")


# ----------------------------------------------------------------- 下載工作
PROG_TMPL = ("download:YTDP|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|"
             "%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s")
ACTIVE = ("queued", "downloading", "processing")
ITEM_RE = re.compile(r"^\[download\] Downloading item (\d+) of (\d+)")


def num(s):
    try:
        return float(s)
    except Exception:
        return None


def public_job(j):
    return {k: v for k, v in j.items() if k not in ("proc", "cmd", "tmpfile", "post")}


def has_active():
    with JOBS_LOCK:
        return any(j["status"] in ACTIVE for j in JOBS.values())


def launch(job):
    job["gen"] += 1
    threading.Thread(target=run_job, args=(job, job["gen"]), daemon=True).start()


def start_download(req):
    sp_search = isinstance(req.get("tags"), dict) and str(req.get("url") or "").startswith("ytsearch")
    url = str(req["url"])[:400] if sp_search else check_url(req.get("url"))
    out_dir = (req.get("dir") or "").strip() or load_config()["download_dir"]
    out_dir = os.path.abspath(os.path.expanduser(out_dir))
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception as e:
        raise AppError("無法建立下載資料夾: %s" % e)

    kind = req.get("kind") or "video"
    post, cmd, extra = None, None, {}
    multi = int(req.get("multi") or 0)

    if kind == "file":
        base, ext = os.path.splitext(os.path.basename(str(req.get("filename") or "download")))
        extra["filename"] = safe_filename(base)[:140] + re.sub(r"[^A-Za-z0-9.]", "", ext)[:12]
        label = "檔案"
        if req.get("via_idm"):
            idm_handoff(url, out_dir, extra["filename"])
            return {"idm": True, "filename": extra["filename"]}
    else:
        exe = tool("yt-dlp")
        if not exe:
            raise AppError("找不到 yt-dlp, 請重新執行安裝檔修復環境")
        res = int(req.get("res") or 0)
        container = req.get("container") if req.get("container") in ("mp4", "mkv") else "mp4"
        cmd = [exe, "--yes-playlist" if multi else "--no-playlist", "--newline", "--encoding", "utf-8",
               "--color", "never", "--progress-template", PROG_TMPL, "-P", out_dir,
               "--concurrent-fragments", "4"] + cookie_args(url)
        if multi:
            cmd += ["--ignore-errors"]
            if req.get("archive"):
                # 記錄下載過的影片代碼, 同一個播放清單再下載時只抓新的 (影片與音訊分開記錄)
                cmd += ["--download-archive", os.path.join(DATA, "downloaded_%s.txt" % ("audio" if kind == "audio" else "video"))]
        if tool("ffmpeg"):
            cmd += ["--ffmpeg-location", os.path.dirname(tool("ffmpeg"))]
        # YouTube 單支影片沿用原本的檔名; 其他網站標題常重複 (例如 IG), 改用「用戶名稱_日期_代碼」
        plain = is_youtube(url) and not multi
        social = "" if is_youtube(url) else (
            "%(channel,uploader_id,uploader|unknown).60B_%(upload_date>%Y%m%d|)s_%(id)s.%(ext)s" if "instagram.com" in url
            else "%(uploader,channel,uploader_id|unknown).60B_%(upload_date>%Y%m%d|)s_%(id)s.%(ext)s")

        if kind == "audio":
            afmt = req.get("audio_format") if req.get("audio_format") in ("mp3", "m4a") else "mp3"
            br = int(req.get("bitrate") or 0)
            br = br if br in (128, 192, 256, 320) else 0
            label = afmt.upper() + (" %dk" % br if (afmt == "mp3" and br) else " 音訊")
            premium = is_youtube(url) and not multi and yt_logged_in()
            if premium:
                label += " · 已登入 YouTube"
                if not sp_search:
                    url = yt_music_url(url)
            if afmt == "mp3":
                cmd += ["-f", PREMIUM_MP3_FMT if premium else "ba/b", "-x", "--audio-format", "mp3",
                        "--audio-quality", ("%dK" % br) if br else "0"]
            else:
                cmd += ["-f", PREMIUM_M4A_FMT if premium else "ba[ext=m4a]/ba/b", "-x", "--audio-format", "m4a"]
            # 專輯封面: 把縮圖裁成正方形 (YouTube Music 的縮圖是 16:9, 專輯圖在中間) 再嵌入音訊檔
            cmd += ["--embed-thumbnail", "--convert-thumbnails", "jpg", "--ppa", COVER_PPA]
            if req.get("lyrics"):
                extra["lyrics"] = True
            if int(req.get("gain") or 0) in GAIN_TARGETS:
                extra["gain"] = {"target": int(req["gain"]), "noclip": req.get("noclip", True) is not False}
            if isinstance(req.get("tags"), dict):  # Spotify 連結: 再用 Spotify 的歌名/歌手/封面覆蓋
                post = {"tags": req["tags"], "cover": str(req.get("cover") or ""), "sp_id": str(req.get("sp_id") or "")[:40]}
                if sp_search:
                    extra["sp_search"] = True
                    t = req["tags"]
                    extra["sp_resolve"] = {"name": str(t.get("title") or ""), "duration": int(req.get("sp_dur") or 0),
                                           "artists": [a.strip() for a in str(t.get("artist") or "").split(",") if a.strip()]}
                    # Spotify 專輯/清單的歌曲: 搜尋 YouTube, 取第一個長度相符 (±10 秒) 的結果
                    d = int(req.get("sp_dur") or 0)
                    if d > 0:
                        cmd += ["--match-filter", "duration>=%d & duration<=%d" % (max(1, d - 10), d + 10)]
                    cmd += ["--max-downloads", "1"]
                name = safe_filename(req.get("filename") or req["tags"].get("title"))
                cmd += ["-o", name.replace("%", "%%") + ".%(ext)s"]
            else:
                cmd += ["--embed-metadata",
                        "-o", social or ("%(title).150B.%(ext)s" if plain else "%(title).100B [%(id)s].%(ext)s")]
        else:
            label = ("%dp" % res if res else "最佳畫質") + " · " + container.upper()
            r = ("res:%d" % res) if res else "res"
            if container == "mp4":
                # 相容優先: 同解析度下優先選 H.264 + AAC
                cmd += ["-f", "bv*+ba/b", "-S", r + ",vcodec:h264,acodec:aac"]
            else:
                cmd += ["-f", "bv*+ba/b", "-S", r]
            cmd += ["--embed-metadata", "--merge-output-format", container, "-o",
                    social or ("%(title).150B [%(height)sp].%(ext)s" if plain else "%(title).100B [%(id)s].%(ext)s")]
        if req.get("sponsorblock") and is_youtube(url) and tool("ffmpeg"):
            cmd += ["--sponsorblock-remove", ",".join(SB_CATS)]
            label += " · 去除業配"
        if multi:
            label = "%d 個項目 · %s" % (multi, label)

    with JOBS_LOCK:
        JOB_SEQ[0] += 1
        jid = "j%d" % JOB_SEQ[0]
        tmpfile = os.path.join(TMP, "%s_%d.txt" % (jid, int(time.time())))
        if cmd:
            cmd += ["--print-to-file", "after_move:%(filepath)s", tmpfile, "--", url]
        job = {
            "id": jid, "url": url, "title": req.get("title") or url,
            "thumb": req.get("thumb") or "", "label": label, "kind": kind,
            "dir": out_dir, "status": "queued", "stage": "等待中", "percent": 0.0,
            "speed": None, "eta": None, "file": "", "error": "", "log": [],
            "created": time.time(), "cmd": cmd, "tmpfile": tmpfile, "proc": None,
            "streams": 0, "cancel": False, "pause": False, "gen": 0, "post": post,
            "multi": multi, "count": 0,
        }
        job.update(extra)
        JOBS[jid] = job
    launch(job)
    return public_job(job)


def run_job(job, gen):
    with SEM:
        if job["gen"] != gen or job["pause"]:
            return
        if job["cancel"]:
            job["status"], job["stage"] = "canceled", "已取消"
            return
        try:
            if job["kind"] == "file":
                run_file_job(job)
            else:
                run_ytdlp_job(job)
        except Exception as e:
            log("job error: %r" % e)
            job["status"], job["stage"], job["error"] = "error", "失敗", "程式內部錯誤: %s" % e


def resolve_search(job):
    """專輯 / 播放清單的歌曲: 先搜尋 YouTube 並評分 (長度相符、官方 Topic 頻道、歌手名稱),
    挑最像的那一個下載; 搜尋失敗時保留原本「第一個長度相符」的方式。"""
    r = job.pop("sp_resolve", None)
    exe = tool("yt-dlp")
    if not r or not r["name"] or not exe:
        return
    job["stage"] = "搜尋最相符的版本"
    try:
        rc, out, err = run([exe, "-J", "--flat-playlist", "--no-warnings", "--encoding", "utf-8", "--",
                            "ytsearch8:" + " ".join(r["artists"][:2] + [r["name"]])], timeout=90)
        entries = (json.loads(out).get("entries") or []) if rc == 0 else []
    except Exception as e:
        log("resolve_search failed: %r" % e)
        return
    best = None
    for i, e in enumerate(entries):
        if not e or not e.get("id"):
            continue
        c = {"id": e["id"], "title": e.get("title") or "", "channel": e.get("channel") or e.get("uploader") or "",
             "duration": int(e.get("duration") or 0)}
        if r["duration"] and c["duration"] and abs(c["duration"] - r["duration"]) > 10:
            continue
        c["score"] = match_score(c, r["name"], r["artists"], r["duration"], i)
        if not best or c["score"] > best["score"]:
            best = c
    if best:
        u = "https://www.youtube.com/watch?v=" + best["id"]
        job["cmd"][-1] = yt_music_url(u) if "--cookies" in job["cmd"] and is_youtube(u) else u
        job["url"] = job["cmd"][-1]
        log("resolve_search picked %s (%s, score %s)" % (best["id"], best["channel"], best["score"]))


def run_ytdlp_job(job):
    job["status"], job["stage"], job["error"] = "downloading", "連線中", ""
    job["streams"] = 0
    if job.get("sp_resolve"):
        resolve_search(job)
        if job["cancel"]:
            job["status"], job["stage"] = "canceled", "已取消"
            return
    try:
        proc = subprocess.Popen(
            job["cmd"], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, creationflags=NOWIN, env=child_env())
    except Exception as e:
        job["status"], job["error"] = "error", "無法啟動下載程式: %s" % e
        return
    job["proc"] = proc
    item = ""
    for raw in proc.stdout:
        line = raw.decode("utf-8", "replace").strip()
        if not line:
            continue
        if line.startswith("YTDP|"):
            p = line.split("|")
            if len(p) >= 6:
                done, total = num(p[1]), num(p[2]) or num(p[3])
                if done is not None and total:
                    job["percent"] = max(0.0, min(100.0, done * 100.0 / total))
                job["speed"], job["eta"] = num(p[4]), num(p[5])
            continue
        job["log"] = (job["log"] + [line])[-40:]
        m = ITEM_RE.match(line)
        if m:
            item = "第 %s/%s 個 · " % (m.group(1), m.group(2))
            job["streams"] = 0
            job["status"], job["stage"], job["percent"] = "downloading", item + "解析中", 0.0
        elif line.startswith("[download] Destination:"):
            job["streams"] += 1
            job["percent"] = 0.0
            job["status"] = "downloading"
            if job["kind"] == "audio":
                job["stage"] = item + "下載音訊"
            else:
                job["stage"] = item + ("下載影像" if job["streams"] == 1 else "下載音訊")
        elif "has already been downloaded" in line:
            job["stage"], job["percent"] = item + "檔案已存在", 100.0
        elif line.startswith("[Merger]"):
            job["status"], job["stage"], job["percent"] = "processing", item + "合併影音中", 100.0
        elif line.startswith("[ExtractAudio]"):
            job["status"], job["stage"], job["percent"] = "processing", item + "轉換音訊中", 100.0
        elif line.startswith(("[EmbedThumbnail]", "[Metadata]", "[VideoRemuxer]", "[VideoConvertor]")):
            job["status"], job["stage"] = "processing", item + "寫入檔案資訊"
        elif line.startswith("ERROR"):
            job["error"] = re.sub(r"^ERROR:\s*", "", line)
    rc = proc.wait()
    job["proc"] = None
    job["speed"] = job["eta"] = None
    if job["pause"] and not job["cancel"]:
        job["status"], job["stage"] = "paused", "已暫停"
        return
    got = []
    try:
        with open(job["tmpfile"], "r", encoding="utf-8", errors="replace") as f:
            got = [l.strip() for l in f.read().splitlines() if l.strip()]
        os.remove(job["tmpfile"])
    except Exception:
        pass
    got = list(dict.fromkeys(got))
    path = got[-1] if got else ""
    if job["cancel"]:
        job["status"], job["stage"] = "canceled", "已取消"
    elif job.get("sp_search") and not got:
        job["status"], job["stage"] = "error", "失敗"
        job["error"] = "在 YouTube 找不到長度相符的版本, 可改貼這首歌的 Spotify 單曲連結, 手動挑選版本"
    elif rc == 0 or (job["multi"] and got) or (rc == 101 and got):
        if job.get("post"):
            job["status"], job["stage"] = "processing", "寫入歌曲資訊與封面"
            try:
                tag_audio(path, job["post"])
            except Exception as e:
                log("tag_audio error: %r" % e)
        gain_note = ""
        if job.get("lyrics"):
            job["status"], job["stage"] = "processing", "下載歌詞"
            try:
                if not add_lyrics(got, (job.get("post") or {}).get("tags")):
                    gain_note = "找不到這首歌的歌詞"
            except Exception as e:
                log("add_lyrics error: %r" % e)
        if job.get("gain"):
            job["status"], job["stage"] = "processing", "調整音量"
            try:
                gain_note = "；".join(x for x in (gain_note, apply_gain(got, job["gain"]["target"], job["gain"]["noclip"])) if x)
            except Exception as e:
                log("apply_gain error: %r" % e)
                gain_note = "音量調整失敗"
        job["status"], job["percent"] = "done", 100.0
        if job["multi"]:
            job["count"] = len(got)
            job["stage"] = "完成 %d 個檔案" % len(got) + (", 部分項目失敗" if rc != 0 else "")
            job["file"] = ""
            if rc == 0:
                job["error"] = gain_note
        else:
            job["stage"], job["file"], job["error"] = "完成", path, gain_note
    else:
        job["status"], job["stage"] = "error", "失敗"
        job["error"] = friendly_error(job["error"] or last_error("\n".join(job["log"])), job["url"])


def kill_proc(proc):
    if not proc or proc.poll() is not None:
        return
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, creationflags=NOWIN, timeout=15)
        else:
            proc.kill()
    except Exception:
        pass


def cancel_job(jid):
    job = JOBS.get(jid)
    if not job:
        return
    if job["status"] in ACTIVE:
        job["cancel"] = True
        if job["status"] == "queued":
            job["status"], job["stage"] = "canceled", "已取消"
        kill_proc(job["proc"])
    elif job["status"] in ("paused", "error"):
        job["cancel"] = True
        job["status"], job["stage"] = "canceled", "已取消"
        if job["kind"] == "file" and job.get("final"):
            for p in (job["final"] + ".part", job["final"] + ".part.json"):
                try:
                    os.remove(p)
                except Exception:
                    pass


def pause_job(jid):
    job = JOBS.get(jid)
    if not job or job["status"] not in ("queued", "downloading"):
        return
    job["pause"] = True
    if job["status"] == "queued":
        job["status"], job["stage"] = "paused", "已暫停"
    kill_proc(job["proc"])


def resume_job(jid):
    job = JOBS.get(jid)
    if not job or job["status"] not in ("paused", "error", "canceled"):
        return
    job["pause"] = job["cancel"] = False
    job["status"], job["stage"], job["error"] = "queued", "等待中", ""
    launch(job)


def open_path(path, reveal=False):
    if not path or not os.path.exists(path):
        raise AppError("找不到檔案或資料夾, 可能已被移動或刪除")
    if IS_WIN:
        if reveal and os.path.isfile(path):
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        else:
            os.startfile(os.path.normpath(path))  # noqa
    else:
        subprocess.Popen(["xdg-open", path], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def pick_folder(initial):
    if not IS_WIN:
        raise AppError("選擇資料夾視窗僅支援 Windows, 請直接輸入路徑")
    script = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$f = New-Object System.Windows.Forms.Form; $f.TopMost = $true;"
        "$d = New-Object System.Windows.Forms.FolderBrowserDialog;"
        "$d.Description = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($env:YTD_DESC));"
        "$d.ShowNewFolderButton = $true;"
        "if ($env:YTD_INIT -and (Test-Path -LiteralPath $env:YTD_INIT)) { $d.SelectedPath = $env:YTD_INIT };"
        "if ($d.ShowDialog($f) -eq [System.Windows.Forms.DialogResult]::OK) {"
        " [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($d.SelectedPath)) }"
    )
    desc = base64.b64encode("選擇影片下載資料夾".encode("utf-8")).decode("ascii")
    out = powershell(script, {"YTD_INIT": initial or "", "YTD_DESC": desc})
    if not out:
        return ""
    try:
        return base64.b64decode(out.splitlines()[-1]).decode("utf-8")
    except Exception:
        return ""


# ----------------------------------------------------------------- 更新機制
def history():
    return read_json(os.path.join(DATA, "update_history.json"), [])


def list_backups():
    if not os.path.isdir(BACKUP):
        return []
    return sorted(d for d in os.listdir(BACKUP) if os.path.isdir(os.path.join(BACKUP, d)))


def safe_member(name):
    n = name.replace("\\", "/")
    if n.startswith("/") or ":" in n or ".." in n.split("/"):
        return None
    return n


def apply_update(data, filename):
    """安裝更新包 YTD_Vx.x.xx.zip。

    更新包內容:  update.json  +  app/ (要覆蓋的程式檔)
    update.json: {"product":"YTD","version":"V0.1.01","requires":"V0.1.00",
                  "notes":["..."],"delete":["app/舊檔.py"]}
    """
    if has_active():
        raise AppError("仍有下載進行中, 請等待完成或取消後再安裝更新")
    m = PKG_RE.match(os.path.basename(filename or ""))
    if not m:
        raise AppError("檔名不符合更新包格式, 應為 YTD_Vx.x.xx.zip (例如 YTD_V0.1.01.zip)")
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
        manifest = json.loads(zf.read("update.json").decode("utf-8-sig"))
    except Exception:
        raise AppError("這不是有效的 YTD 更新包 (缺少 update.json 或壓縮檔損毀)")
    new = manifest.get("version", "")
    cur = current_version()
    if manifest.get("product") != "YTD" or not vtuple(new):
        raise AppError("更新包資訊不正確")
    if new != m.group(1):
        raise AppError("檔名版本 (%s) 與更新包內容版本 (%s) 不一致" % (m.group(1), new))
    if vtuple(new) <= (vtuple(cur) or (0, 0, 0)):
        raise AppError("目前版本 %s 已等於或高於更新包版本 %s, 不需安裝" % (cur, new))
    req = manifest.get("requires")
    if req and vtuple(req) and (vtuple(cur) or (0, 0, 0)) < vtuple(req):
        raise AppError("此更新包需要先升級到 %s (目前為 %s)" % (req, cur))

    members = []
    for info in zf.infolist():
        n = safe_member(info.filename)
        if n is None:
            raise AppError("更新包含有不安全的路徑, 已拒絕安裝")
        if n == "update.json" or n.endswith("/"):
            continue
        if not n.startswith("app/"):
            raise AppError("更新包含有 app 資料夾以外的檔案, 已拒絕安裝")
        members.append((info, n))
    if not members:
        raise AppError("更新包內沒有任何程式檔")

    stamp = time.strftime("%Y%m%d_%H%M%S")
    bdir = os.path.join(BACKUP, "%s_%s" % (cur, stamp))
    os.makedirs(BACKUP, exist_ok=True)
    shutil.copytree(HERE, bdir, ignore=shutil.ignore_patterns("__pycache__"))
    try:
        for info, n in members:
            dest = os.path.join(ROOT, *n.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "wb") as f:
                f.write(zf.read(info))
        for d in manifest.get("delete") or []:
            n = safe_member(d)
            if n and n.startswith("app/"):
                target = os.path.join(ROOT, *n.split("/"))
                if os.path.isfile(target):
                    os.remove(target)
        vfile = os.path.join(HERE, "version.json")
        v = read_json(vfile, {})
        v.update({"version": new, "date": manifest.get("date") or time.strftime("%Y-%m-%d")})
        write_json(vfile, v)
    except Exception as e:
        shutil.copytree(bdir, HERE, dirs_exist_ok=True)
        log("update failed, restored: %r" % e)
        raise AppError("安裝更新時發生錯誤, 已還原為原版本: %s" % e)

    h = history()
    h.append({"version": new, "from": cur, "time": time.strftime("%Y-%m-%d %H:%M:%S"),
              "notes": manifest.get("notes") or [], "backup": os.path.basename(bdir)})
    write_json(os.path.join(DATA, "update_history.json"), h)
    for old in list_backups()[:-5]:
        shutil.rmtree(os.path.join(BACKUP, old), ignore_errors=True)
    log("updated %s -> %s" % (cur, new))
    return {"version": new, "from": cur, "notes": manifest.get("notes") or []}


def rollback():
    if has_active():
        raise AppError("仍有下載進行中, 請等待完成或取消後再還原")
    backups = list_backups()
    if not backups:
        raise AppError("沒有可還原的備份")
    name = backups[-1]
    src = os.path.join(BACKUP, name)
    cur = current_version()
    for entry in os.listdir(HERE):
        p = os.path.join(HERE, entry)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
        else:
            try:
                os.remove(p)
            except Exception:
                pass
    shutil.copytree(src, HERE, dirs_exist_ok=True)
    shutil.rmtree(src, ignore_errors=True)
    new = current_version()
    h = history()
    h.append({"version": new, "from": cur, "time": time.strftime("%Y-%m-%d %H:%M:%S"),
              "notes": ["還原至 %s" % new], "backup": ""})
    write_json(os.path.join(DATA, "update_history.json"), h)
    log("rollback %s -> %s" % (cur, new))
    return {"version": new, "from": cur}


# ----------------------------------------------------------------- 直接登入 (YTD 專用瀏覽器視窗)
# 開一個使用獨立設定檔的 Edge / Chrome 視窗讓使用者自己登入, 登入完成後由程式讀出該視窗的
# 登入資料存成 cookies.txt, 省去手動匯出。只讀這個專用視窗, 不碰使用者平常的瀏覽器。
BROWSER_DIR = os.path.join(DATA, "browser")
LOGIN_URLS = {"instagram": "https://www.instagram.com/accounts/login/",
              "facebook": "https://www.facebook.com/login/",
              "threads": "https://www.threads.com/login",
              "x": "https://x.com/i/flow/login",
              "youtube": "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F"}
LOGIN = {"state": "idle", "site": "", "msg": ""}


def ws_connect(port, path):
    s = socket.create_connection(("127.0.0.1", port), timeout=10)
    key = base64.b64encode(os.urandom(16)).decode("ascii")
    s.sendall(("GET %s HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n" % (path, port, key)).encode("ascii"))
    buf = b""
    while b"\r\n\r\n" not in buf:
        c = s.recv(4096)
        if not c:
            raise OSError("websocket handshake closed")
        buf += c
    head, rest = buf.split(b"\r\n\r\n", 1)
    if b" 101 " not in head.split(b"\r\n")[0]:
        raise OSError("websocket handshake refused")
    return s, rest


def ws_send(s, data, opcode=1):
    payload = data if isinstance(data, bytes) else data.encode("utf-8")
    n, mask = len(payload), os.urandom(4)
    head = bytes([0x80 | opcode])
    if n < 126:
        head += bytes([0x80 | n])
    elif n < 65536:
        head += bytes([0x80 | 126]) + n.to_bytes(2, "big")
    else:
        head += bytes([0x80 | 127]) + n.to_bytes(8, "big")
    s.sendall(head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))


def ws_recv(s, buf):
    """讀取一則完整訊息; 回傳 (文字, 剩餘緩衝)。"""
    def need(n):
        nonlocal buf
        while len(buf) < n:
            c = s.recv(65536)
            if not c:
                raise OSError("websocket closed")
            buf += c
    message = b""
    while True:
        need(2)
        fin, opcode, n = buf[0] & 0x80, buf[0] & 0x0F, buf[1] & 0x7F
        masked, pos = buf[1] & 0x80, 2
        if n == 126:
            need(4)
            n, pos = int.from_bytes(buf[2:4], "big"), 4
        elif n == 127:
            need(10)
            n, pos = int.from_bytes(buf[2:10], "big"), 10
        if masked:
            need(pos + 4)
            mask, pos = buf[pos:pos + 4], pos + 4
        need(pos + n)
        payload, buf = buf[pos:pos + n], buf[pos + n:]
        if masked:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        if opcode == 8:
            raise OSError("websocket closed")
        if opcode == 9:
            ws_send(s, payload, 10)
            continue
        if opcode == 10:
            continue
        message += payload
        if fin:
            return message.decode("utf-8", "replace"), buf


def cdp(port, method, params=None):
    info = http_local("http://127.0.0.1:%d/json/version" % port, timeout=3)
    path = urllib.request.urlparse(info["webSocketDebuggerUrl"]).path
    s, buf = ws_connect(port, path)
    try:
        ws_send(s, json.dumps({"id": 1, "method": method, "params": params or {}}))
        while True:
            msg, buf = ws_recv(s, buf)
            j = json.loads(msg)
            if j.get("id") == 1:
                if "error" in j:
                    raise OSError(str(j["error"].get("message")))
                return j.get("result") or {}
    finally:
        s.close()


def read_port(portfile):
    try:
        with open(portfile, "r", encoding="ascii", errors="replace") as f:
            return int(f.readline().strip())
    except Exception:
        return 0


def site_cookies(cookies, key):
    d = LOGIN_SITES[key][1]
    return [c for c in cookies if isinstance(c, dict)
            and (str(c.get("domain", "")).lstrip(".").lower() == d
                 or str(c.get("domain", "")).lower().endswith("." + d))]


def browser_logged_in(cookies, key):
    names = {c.get("name") for c in site_cookies(cookies, key) if c.get("value")}
    return all(n in names for n in LOGIN_SITES[key][2])


def save_browser_cookies(cookies):
    """把專用視窗裡 Instagram / Facebook 的登入資料寫成 cookies.txt (保留檔案裡其他網站的資料)。"""
    keep, new, doms = [], [], set()
    for key in LOGIN_SITES:
        for c in site_cookies(cookies, key):
            dom = str(c.get("domain", ""))
            doms.add(LOGIN_SITES[key][1])
            exp = c.get("expires")
            exp = int(exp) if isinstance(exp, (int, float)) and exp > 0 else 0
            line = "\t".join([dom, "TRUE" if dom.startswith(".") else "FALSE", str(c.get("path") or "/"),
                              "TRUE" if c.get("secure") else "FALSE", str(exp),
                              str(c.get("name") or ""), str(c.get("value") or "")])
            new.append(("#HttpOnly_" if c.get("httpOnly") else "") + line)
    if os.path.isfile(COOKIE_FILE):
        with open(COOKIE_FILE, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                raw = line.rstrip("\r\n")
                body = raw[len("#HttpOnly_"):] if raw.startswith("#HttpOnly_") else raw
                if not body.strip() or body.startswith("#") or len(body.split("\t")) < 7:
                    continue
                dom = body.split("\t")[0].lstrip(".").lower()
                if not any(dom == d or dom.endswith("." + d) for d in doms):
                    keep.append(raw)
    with open(COOKIE_FILE, "w", encoding="utf-8", newline="\n") as f:
        f.write("# Netscape HTTP Cookie File\n" + "\n".join(keep + new) + "\n")
    cfg = load_config()
    cfg["login_mode"] = "file"
    save_config(cfg)


def start_login(site):
    if site not in LOGIN_URLS:
        raise AppError("不支援的網站")
    if LOGIN["state"] == "waiting":
        raise AppError("登入視窗已經開啟, 請在那個視窗完成登入")
    exe = find_browser()
    if not exe:
        raise AppError("找不到 Edge 或 Chrome, 無法開啟登入視窗。可改用匯入 cookies.txt。")
    LOGIN.update(state="waiting", site=site, msg="")
    threading.Thread(target=login_worker, args=(site, exe), daemon=True).start()


def close_login_browser():
    port = read_port(os.path.join(BROWSER_DIR, "DevToolsActivePort"))
    if port:
        try:
            cdp(port, "Browser.close")
        except Exception:
            pass


def login_worker(site, exe):
    name = LOGIN_SITES[site][0]
    portfile = os.path.join(BROWSER_DIR, "DevToolsActivePort")
    try:
        os.makedirs(BROWSER_DIR, exist_ok=True)
        if read_port(portfile):  # 上次的視窗還開著: 先關掉
            close_login_browser()
            time.sleep(1.5)
        try:
            os.remove(portfile)
        except Exception:
            pass
        args = [exe, "--user-data-dir=" + BROWSER_DIR, "--remote-debugging-port=0", "--no-first-run",
                "--no-default-browser-check", "--window-size=520,820"]
        args += os.environ.get("YTD_BROWSER_ARGS", "").split()
        subprocess.Popen(args + ["--new-window", LOGIN_URLS[site]], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        start, port, alive, misses = time.time(), 0, False, 0
        while LOGIN["state"] == "waiting":
            time.sleep(1.5)
            if time.time() - start > 900:
                LOGIN.update(state="failed", msg="等待登入逾時, 請重新再試一次。")
                close_login_browser()
                return
            port = port or read_port(portfile)
            if not port:
                if time.time() - start > 40:
                    LOGIN.update(state="failed", msg="登入視窗沒有成功啟動。可改用匯入 cookies.txt。")
                    return
                continue
            try:
                cookies = cdp(port, "Storage.getCookies").get("cookies") or []
                alive, misses = True, 0
            except Exception:
                misses += 1
                if (alive and misses >= 2) or misses >= 20:
                    LOGIN.update(state="failed", msg="登入視窗已關閉, 尚未完成登入。")
                    return
                continue
            if browser_logged_in(cookies, site):
                time.sleep(2.5)  # 等登入後續的資料寫完
                try:
                    cookies = cdp(port, "Storage.getCookies").get("cookies") or cookies
                except Exception:
                    pass
                save_browser_cookies(cookies)
                close_login_browser()
                LOGIN.update(state="done", msg="已登入 %s" % name)
                log("login captured for %s" % site)
                return
    except Exception as e:
        log("login_worker error: %r" % e)
        LOGIN.update(state="failed", msg="開啟登入視窗時發生錯誤: %s" % e)


# ----------------------------------------------------------------- 線上更新 (GitHub)
UPDATE_REPO = "M1isty/YTD-Download"
UPDATE_BRANCH = "main"
UPDATE_API = os.environ.get("YTD_UPDATE_API") or "https://api.github.com"
TOKEN_RE = re.compile(r"^[A-Za-z0-9_]{20,255}$")


def gh_get(path, limit=64 << 20):
    """讀取更新用儲存庫裡的檔案 (公開的不需金鑰; 私人的需要在設定裡填入唯讀金鑰)。"""
    headers = {"User-Agent": "YTD-Updater", "Accept": "application/vnd.github.raw+json",
               "X-GitHub-Api-Version": "2022-11-28"}
    token = load_config().get("update_token") or ""
    if token:
        headers["Authorization"] = "Bearer " + token
    url = "%s/repos/%s/contents/%s?ref=%s" % (UPDATE_API, UPDATE_REPO, urllib.request.quote(path), UPDATE_BRANCH)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=30) as r:
            return r.read(limit)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise AppError("找不到更新資訊。" + ("金鑰沒有這個儲存庫的讀取權限, 或尚未上傳更新。" if token
                           else "更新用的 GitHub 儲存庫是私人的 (需要先在下方填入金鑰), 或尚未上傳更新。"))
        if e.code in (401, 403):
            raise AppError("GitHub 拒絕存取 (%d): %s" % (e.code, "金鑰無效或已過期。" if token else "查詢太頻繁, 請稍後再試。"))
        raise AppError("連線 GitHub 失敗 (HTTP %d)" % e.code)
    except AppError:
        raise
    except Exception as e:
        raise AppError("連線 GitHub 失敗: %s" % e)


def check_update():
    try:
        latest = json.loads(gh_get("updates/latest.json", 1 << 20).decode("utf-8-sig"))
    except AppError:
        raise
    except Exception:
        raise AppError("更新資訊格式不正確")
    ver, cur = str(latest.get("version") or ""), current_version()
    if not vtuple(ver) or not re.match(r"^YTD_V\d+\.\d+\.\d+\.zip$", str(latest.get("file") or "")):
        raise AppError("更新資訊格式不正確")
    return {"current": cur, "latest": ver, "available": vtuple(ver) > (vtuple(cur) or (0, 0, 0)),
            "notes": [str(n) for n in (latest.get("notes") or [])][:20],
            "file": latest["file"], "sha256": str(latest.get("sha256") or "").lower()}


def online_update():
    info = check_update()
    if not info["available"]:
        raise AppError("目前已是最新版本 %s" % info["current"])
    data = gh_get("updates/" + info["file"])
    if not info["sha256"] or hashlib.sha256(data).hexdigest() != info["sha256"]:
        raise AppError("下載的更新包驗證失敗 (檔案不完整或被更動), 已取消更新")
    return apply_update(data, info["file"])


def public_config():
    cfg = load_config()
    cfg["has_update_token"] = bool(cfg.pop("update_token", ""))
    return cfg


def update_core():
    exe = tool("yt-dlp")
    if not exe:
        raise AppError("找不到 yt-dlp")
    if has_active():
        raise AppError("仍有下載進行中, 請稍後再更新下載核心")
    channel = load_config().get("core_channel")
    channel = channel if channel in ("stable", "nightly") else "stable"
    rc, out, err = run([exe, "--update-to", channel], timeout=300)
    fetch_ytdlp_version()
    text = (out + "\n" + err).strip()
    if rc != 0:
        raise AppError("更新下載核心失敗: " + last_error(text))
    return {"version": STATE["ytdlp_version"], "channel": channel, "output": text[-600:]}


def fetch_ytdlp_version():
    try:
        exe = tool("yt-dlp")
        if exe:
            rc, out, _ = run([exe, "--version"], timeout=60)
            STATE["ytdlp_version"] = out.strip().splitlines()[0] if out.strip() else ""
    except Exception:
        pass


# ----------------------------------------------------------------- 程式生命週期
def shutdown(code=0):
    with JOBS_LOCK:
        procs = [j["proc"] for j in JOBS.values() if j.get("proc")]
    for p in procs:
        kill_proc(p)
    try:
        os.remove(os.path.join(DATA, "server.json"))
    except Exception:
        pass
    os._exit(code)


def restart_later():
    def go():
        time.sleep(0.6)
        args = [sys.executable, os.path.abspath(__file__), "--no-browser", "--port", str(STATE["port"])]
        flags = (0x00000008 | 0x00000200) if IS_WIN else 0  # DETACHED | NEW_PROCESS_GROUP
        subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=flags, cwd=ROOT, close_fds=True)
        try:
            os.remove(os.path.join(DATA, "server.json"))
        except Exception:
            pass
        os._exit(0)
    threading.Thread(target=go, daemon=True).start()


def watchdog():
    while True:
        time.sleep(5)
        if has_active():
            continue
        now = time.time()
        bye = STATE["bye_at"]
        if bye and now - bye > 8 and STATE["last_ping"] < bye:
            shutdown()
        if now - STATE["last_ping"] > 180:
            shutdown()


def find_browser():
    """尋找 Edge 或 Chrome 的執行檔 (Edge 優先)。"""
    override = os.environ.get("YTD_BROWSER")
    if override:
        return override
    if not IS_WIN:
        for name in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge"):
            if shutil.which(name):
                return shutil.which(name)
        return None
    cands = []
    for key in ("ProgramFiles(x86)", "ProgramFiles", "LocalAppData"):
        base = os.environ.get(key)
        if base:
            cands.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
            cands.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
    cands.sort(key=lambda p: "chrome.exe" in p)
    for c in cands:
        if os.path.isfile(c):
            return c
    return None


def open_ui(url):
    exe = find_browser() if IS_WIN else None
    if exe:
        try:
            subprocess.Popen([exe, "--app=" + url, "--window-size=1240,900"],
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return
        except Exception:
            pass
    try:
        webbrowser.open(url)
    except Exception:
        pass


def http_local(url, timeout=1.5):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def find_running():
    info = read_json(os.path.join(DATA, "server.json"), None)
    if not info:
        return None
    try:
        url = "http://127.0.0.1:%d/" % int(info["port"])
        if http_local(url + "api/ping").get("app") == "YTD":
            return url
    except Exception:
        pass
    return None


# ----------------------------------------------------------------- HTTP
class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = not IS_WIN  # Windows 的 SO_REUSEADDR 會讓兩個程式搶同一個埠


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "YTD"

    def log_message(self, *a):
        pass

    # --- 回應
    def send_bytes(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, obj, code=200):
        self.send_bytes(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                        "application/json; charset=utf-8")

    # --- 安全檢查: 只接受本機頁面發出的請求
    def origin_ok(self):
        host = (self.headers.get("Host") or "").lower()
        good = ("127.0.0.1:%d" % STATE["port"], "localhost:%d" % STATE["port"])
        if host not in good:
            return False
        origin = self.headers.get("Origin")
        if origin and origin.lower() not in tuple("http://" + g for g in good):
            return False
        return True

    def authed(self):
        return self.origin_ok() and secrets.compare_digest(
            self.headers.get("X-YTD-Token") or "", TOKEN)

    def body(self, limit=1 << 20):
        n = int(self.headers.get("Content-Length") or 0)
        if n > limit:
            raise AppError("資料過大")
        return self.rfile.read(n) if n else b""

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if not self.origin_ok():
            return self.send_json({"error": "forbidden"}, 403)
        if path in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), "r", encoding="utf-8") as f:
                html = f.read().replace("__YTD_TOKEN__", TOKEN)
            STATE["last_ping"] = time.time()
            return self.send_bytes(200, html.encode("utf-8"), "text/html; charset=utf-8")
        if path in ("/favicon.ico", "/icon.ico"):
            try:
                with open(os.path.join(HERE, "icon.ico"), "rb") as f:
                    return self.send_bytes(200, f.read(), "image/x-icon")
            except Exception:
                return self.send_bytes(404, b"", "text/plain")
        if path == "/api/ping":
            return self.send_json({"app": "YTD", "version": current_version()})
        if not self.authed():
            return self.send_json({"error": "forbidden"}, 403)
        STATE["last_ping"] = time.time()
        if path == "/api/status":
            return self.send_json({
                "version": current_version(),
                "ytdlp_version": STATE["ytdlp_version"],
                "has_ytdlp": bool(tool("yt-dlp")),
                "has_ffmpeg": bool(tool("ffmpeg")), "has_mp3tag": bool(find_mp3tag()), "has_idm": bool(find_idm()), "gain_tool": gain_tool_name(),
                "has_deno": bool(tool("deno")),
                "config": public_config(),
                "update_repo": UPDATE_REPO,
                "root": ROOT,
                "history": history()[-20:],
                "can_rollback": bool(list_backups()),
                "has_cookie_file": os.path.isfile(COOKIE_FILE),
                "cookie_sites": cookie_summary(),
            })
        if path == "/api/login-state":
            return self.send_json(dict(LOGIN))
        if path == "/api/check-update":
            try:
                return self.send_json({"ok": True, **check_update()})
            except AppError as e:
                return self.send_json({"ok": False, "error": str(e)})
        if path == "/api/jobs":
            with JOBS_LOCK:
                jobs = [public_job(j) for j in JOBS.values()]
            jobs.sort(key=lambda j: j["created"], reverse=True)
            return self.send_json({"jobs": jobs})
        return self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        try:
            if path == "/api/bye":
                if self.origin_ok() and self.headers.get("Origin"):
                    STATE["bye_at"] = time.time()
                self.body()
                return self.send_json({"ok": True})
            if not self.authed():
                return self.send_json({"error": "forbidden"}, 403)
            STATE["last_ping"] = time.time()

            if path == "/api/update":
                data = self.body(limit=80 << 20)
                name = urllib.request.unquote(self.headers.get("X-Filename") or "")
                result = apply_update(data, name)
                self.send_json({"ok": True, **result})
                return restart_later()

            if path == "/api/cookies":
                n, sites = save_cookie_file(self.body(limit=4 << 20))
                return self.send_json({"ok": True, "count": n, "sites": sites})

            raw = self.body()
            req = json.loads(raw.decode("utf-8")) if raw else {}

            if path == "/api/analyze":
                return self.send_json({"ok": True, "info": analyze(req.get("url"))})
            if path == "/api/stream":
                return self.send_json({"ok": True, "url": stream_url(req.get("url"))})
            if path == "/api/download":
                return self.send_json({"ok": True, "job": start_download(req)})
            if path == "/api/cancel":
                cancel_job(req.get("id"))
                return self.send_json({"ok": True})
            if path == "/api/pause":
                pause_job(req.get("id"))
                return self.send_json({"ok": True})
            if path == "/api/resume":
                resume_job(req.get("id"))
                return self.send_json({"ok": True})
            if path == "/api/login-start":
                start_login(req.get("site"))
                return self.send_json({"ok": True})
            if path == "/api/login-cancel":
                if LOGIN["state"] == "waiting":
                    LOGIN.update(state="idle", msg="")
                    threading.Thread(target=close_login_browser, daemon=True).start()
                return self.send_json({"ok": True})
            if path == "/api/online-update":
                result = online_update()
                self.send_json({"ok": True, **result})
                return restart_later()
            if path == "/api/update-token":
                tok = str(req.get("token") or "").strip()
                if tok and not TOKEN_RE.match(tok):
                    raise AppError("金鑰格式不正確")
                cfg = load_config()
                cfg["update_token"] = tok
                save_config(cfg)
                return self.send_json({"ok": True})
            if path == "/api/login-clear":
                try:
                    close_login_browser()
                    time.sleep(1)
                    shutil.rmtree(BROWSER_DIR, ignore_errors=True)
                    os.remove(COOKIE_FILE)
                except Exception:
                    pass
                cfg = load_config()
                cfg["login_mode"] = "none"
                save_config(cfg)
                return self.send_json({"ok": True})
            if path == "/api/remove":
                with JOBS_LOCK:
                    j = JOBS.get(req.get("id"))
                    if j and j["status"] not in ACTIVE:
                        del JOBS[j["id"]]
                return self.send_json({"ok": True})
            if path == "/api/clear":
                with JOBS_LOCK:
                    for k in [k for k, j in JOBS.items() if j["status"] not in ACTIVE]:
                        del JOBS[k]
                return self.send_json({"ok": True})
            if path == "/api/pick-folder":
                return self.send_json({"ok": True, "path": pick_folder(req.get("initial"))})
            if path == "/api/config":
                cfg = load_config()
                if req.get("download_dir"):
                    cfg["download_dir"] = str(req["download_dir"]).strip()
                if req.get("container") in ("mp4", "mkv"):
                    cfg["container"] = req["container"]
                if req.get("login_mode") in ("none", "file") + BROWSERS:
                    if req["login_mode"] == "file" and not os.path.isfile(COOKIE_FILE):
                        raise AppError("尚未匯入 cookies.txt")
                    cfg["login_mode"] = req["login_mode"]
                if req.get("core_channel") in ("stable", "nightly"):
                    cfg["core_channel"] = req["core_channel"]
                if req.get("gain") in (0,) + GAIN_TARGETS:
                    cfg["gain"] = req["gain"]
                for key in ("sponsorblock", "use_idm", "skip_downloaded", "noclip", "lyrics"):
                    if isinstance(req.get(key), bool):
                        cfg[key] = req[key]
                if req.get("mp3_bitrate") in (128, 192, 256, 320):
                    cfg["mp3_bitrate"] = req["mp3_bitrate"]
                save_config(cfg)
                cfg.pop("update_token", None)
                return self.send_json({"ok": True, "config": cfg})
            if path == "/api/gain-tool":
                install_gain_tool()
                return self.send_json({"ok": True, "gain_tool": gain_tool_name()})
            if path == "/api/open":
                j = JOBS.get(req.get("id")) if req.get("id") else None
                if j:
                    if req.get("what") == "mp3tag":
                        exe = find_mp3tag()
                        if not exe:
                            raise AppError("找不到 Mp3tag, 請先到 https://www.mp3tag.de/ 下載安裝")
                        folder = os.path.dirname(j["file"]) if os.path.isfile(j["file"] or "") else j["dir"]
                        subprocess.Popen([exe, "/fp:" + folder.rstrip("\\/")], cwd=folder)
                    elif req.get("what") == "file":
                        open_path(j["file"])
                    else:
                        open_path(j["file"] if os.path.isfile(j["file"] or "") else j["dir"], reveal=True)
                else:
                    open_path(req.get("path") or load_config()["download_dir"])
                return self.send_json({"ok": True})
            if path == "/api/update-core":
                return self.send_json({"ok": True, **update_core()})
            if path == "/api/rollback":
                result = rollback()
                self.send_json({"ok": True, **result})
                return restart_later()
            if path == "/api/quit":
                self.send_json({"ok": True})
                threading.Timer(0.3, shutdown).start()
                return
            return self.send_json({"error": "not found"}, 404)
        except AppError as e:
            return self.send_json({"ok": False, "error": str(e)}, 200)
        except Exception as e:
            log("handler error %s: %r" % (path, e))
            return self.send_json({"ok": False, "error": "程式內部錯誤: %s" % e}, 200)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--port", type=int, default=0)
    args = ap.parse_args()

    os.makedirs(TMP, exist_ok=True)
    if sys.stdout is None or sys.stderr is None:  # pythonw 沒有主控台
        f = open(os.path.join(DATA, "ytd.log"), "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = f

    if not args.no_browser:
        running = find_running()
        if running:
            open_ui(running)
            return

    httpd = None
    deadline = time.time() + (20 if args.port else 0)
    while httpd is None:
        for port in ([args.port] if args.port else PORTS):
            try:
                httpd = Server(("127.0.0.1", port), Handler)
                break
            except OSError:
                continue
        if httpd is None:
            if time.time() > deadline:
                log("no free port")
                return
            time.sleep(0.4)

    STATE["port"] = httpd.server_address[1]
    STATE["httpd"] = httpd
    write_json(os.path.join(DATA, "server.json"), {"port": STATE["port"], "pid": os.getpid()})
    for name in os.listdir(TMP):
        try:
            os.remove(os.path.join(TMP, name))
        except Exception:
            pass
    threading.Thread(target=watchdog, daemon=True).start()
    threading.Thread(target=fetch_ytdlp_version, daemon=True).start()
    url = "http://127.0.0.1:%d/" % STATE["port"]
    log("YTD %s started on %s" % (current_version(), url))
    if not args.no_browser:
        open_ui(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        shutdown()


if __name__ == "__main__":
    main()
