﻿# YTD 影片下載器 - 解除安裝 (由 uninstall.bat 呼叫)
$ErrorActionPreference = 'Continue'
$root = "$env:YTD_ROOT".TrimEnd('\')
Write-Host ''
Write-Host '  YTD 影片下載器 解除安裝' -ForegroundColor Yellow
Write-Host "  安裝位置: $root"
Write-Host '  (已下載的影片不會被刪除)'
Write-Host ''
if ((-not $root) -or ((Split-Path -Leaf $root) -ne 'YTD') -or (-not (Test-Path -LiteralPath (Join-Path $root 'app\server.py')))) {
  Write-Host '  找不到有效的 YTD 安裝資料夾, 已取消。' -ForegroundColor Red
  Read-Host '  按 Enter 關閉' | Out-Null
  exit 1
}
$ans = Read-Host '  確定要移除 YTD 嗎? 輸入 Y 後按 Enter 繼續'
if ($ans -notmatch '^[Yy]') { exit 0 }

Get-Process -Name pythonw, python, yt-dlp, ffmpeg, deno -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -and $_.Path.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) } |
  Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

foreach ($p in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  foreach ($name in @('YTD 影片下載器.lnk', 'YTD.lnk')) {
    $f = Join-Path $p $name
    if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue }
  }
}
Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue
if (Test-Path -LiteralPath $root) { Write-Host '  部分檔案使用中無法刪除, 請手動刪除資料夾。' -ForegroundColor Yellow }
else { Write-Host '  已移除完成。' -ForegroundColor Green }
Read-Host '  按 Enter 關閉' | Out-Null
